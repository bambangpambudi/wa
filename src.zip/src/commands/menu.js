import fs from 'node:fs/promises';
import path from 'node:path';
import { commandList } from '../lib/handler.js';
import { getStats } from '../lib/database.js';
import { smallCaps } from '../lib/utils.js';

// Only primary command names are shown in the menu. Aliases remain hidden.
const categories = {
  General: ['menu', 'ping', 'runtime', 'botinfo', 'owner', 'jid', 'timestamp', 'server', 'speed', 'memory', 'date', 'time'],
  User: ['afk'],
  Group: ['admins'],
  Moderation: ['antilink', 'antitoxic', 'antispam', 'mute', 'unmute', 'warn', 'unwarn', 'warnings', 'resetwarn'],
  Statistics: ['groupstats'],
  Sticker: ['sticker', 'brat', 'bratgif', 'toimg', 'viewonce'],
  Tools: ['calc', 'base64', 'quote', 'aio', 'iqc', 'ampremium'],
  Store: ['store'],
};

// Owner-only commands are shown exclusively in .menuowner.
const ownerOnlyCommands = new Set([
  'broadcast', 'restart', 'public', 'setprefix',
  'ampgrant', 'ampadd', 'ampremove', 'ampreset', 'amplimit',
  'safety', 'anticall',
  'me'
]);

// Store management commands are kept out of .help/.menu and shown in .menuowner.
// The public Store catalog command is intentionally visible in .menu.
// Note: .p is an alias, so it is not listed in the menu automatically.
const storeCommands = new Set([
  'addcategory', 'delcategory', 'listcategory', 'setcategorybanner',
  'setstorename', 'setstorebanner', 'addproduct', 'delproduct', 'editproduct',
  'storecopy', 'storeaccess'
]);

// Group-admin commands are shown exclusively in .menuadmin.
const adminMenuCommands = new Set([
  'menuadmin', 'groups',
  'hidetag', 'mentionall', 'promote', 'demote', 'kick', 'add',
  'linkgroup', 'revoke', 'setname', 'setdesc', 'setppgroup',
  'setwelcome', 'setgoodbye', 'setwelcomeimage', 'setgoodbyeimage',
  'welcome', 'goodbye', 'open', 'close',
  'antilink', 'antitoxic', 'antispam', 'mute', 'unmute',
  'warn', 'unwarn', 'warnings', 'resetwarn'
]);

const hiddenFromMainMenu = new Set([
  ...ownerOnlyCommands,
  ...storeCommands,
  ...adminMenuCommands
]);

const labels = {
  General: 'ɢᴇɴᴇʀᴀʟ',
  User: 'ᴜsᴇʀ',
  Group: 'ɢʀᴏᴜᴘ ᴍᴀɴᴀɢᴇᴍᴇɴᴛ',
  Moderation: 'ᴍᴏᴅᴇʀᴀᴛɪᴏɴ',
  Statistics: 'ɢʀᴏᴜᴘ sᴛᴀᴛɪsᴛɪᴄs',
  Sticker: 'sᴛɪᴄᴋᴇʀ & ᴍᴇᴅɪᴀ',
  Tools: 'ᴛᴏᴏʟs',
  Store: 'sᴛᴏʀᴇ',
  Other: 'ᴏᴛʜᴇʀ'
};

const formatCommand = (prefix, name) => `${prefix}${String(name).toLowerCase()}`;



function cleanNumber(value) {
  return String(value || '').split('@')[0].split(':')[0].replace(/\D/g, '');
}

function getJakartaDateTime() {
  const now = new Date();
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Jakarta',
    year: 'numeric', month: 'long', day: 'numeric', weekday: 'long',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
  }).formatToParts(now);
  const get = (type) => parts.find((part) => part.type === type)?.value || '';
  const weekdayMap = {
    Sunday: 'Sunday', Monday: 'Monday', Tuesday: 'Tuesday', Wednesday: 'Wednesday',
    Thursday: 'Thursday', Friday: 'Friday', Saturday: 'Saturday'
  };

  const hijri = new Intl.DateTimeFormat('id-ID-u-ca-islamic-umalqura', {
    timeZone: 'Asia/Jakarta', day: 'numeric', month: 'long', year: 'numeric'
  }).format(now);

  return {
    weekday: weekdayMap[get('weekday')] || get('weekday'),
    date: `${get('day')} ${get('month')} ${get('year')}`,
    time: `${get('hour')}:${get('minute')}:${get('second')} WIB`,
    hijri
  };
}

function getGreeting(hour) {
  if (hour >= 4 && hour < 11) return 'Good Morning';
  if (hour >= 11 && hour < 15) return 'Good Afternoon';
  if (hour >= 15 && hour < 18) return 'Good Evening';
  return 'Good Night';
}

function getJakartaHour() {
  const value = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Jakarta', hour: '2-digit', hour12: false
  }).format(new Date());
  return Number(value === '24' ? '0' : value);
}

function availableCommands(available) {
  const visible = new Set([...available].filter((name) => !hiddenFromMainMenu.has(name)));
  const sections = Object.entries(categories)
    .map(([category, names]) => [category, names.filter((name) => visible.has(name))])
    .filter(([, names]) => names.length > 0);

  return sections;
}

function buildHelpText(ctx, available) {
  const stats = getStats();
  const { weekday, date, time, hijri } = getJakartaDateTime();
  const senderJid = ctx.senderDisplayJid || ctx.sender;
  const number = cleanNumber(senderJid);
  const pushName = String(ctx.message?.pushName || '').trim();
  const displayName = pushName || number || 'User';
  const mentionName = number ? `@${number}` : `@${displayName}`;
  const greeting = getGreeting(getJakartaHour());
  const features = available.size;
  const status = ctx.isOwner ? 'Owner' : (ctx.isGroup && ctx.isAdmin ? 'Admin' : 'User');

  const commandSections = availableCommands(available).map(([category, names]) => {
    const commandLines = names.map((name) => `• ${smallCaps(formatCommand(ctx.config.prefix, name))}`).join('\n');
    return `▧──···「 *${smallCaps(labels[category])}* 」\n${commandLines}`;
  }).join('\n\n');

  return [
    `${smallCaps('Halo,')} ${smallCaps(greeting)} ${mentionName} 👋`,
    '',
    `*${smallCaps('STATS')} :*`,
    `▸ ${smallCaps('FEATURES')}: ${features}`,
    `▸ ${smallCaps('STATUS')}: ${smallCaps(status)}`,
    `▸ ${smallCaps('LIMIT')}: ${ctx.config.limit ?? 25}`,
    '',
    `*${smallCaps('DATE & TIME')} :*`,
    `▸ ${smallCaps(weekday)}, ${smallCaps(date)}`,
    `▸ ${smallCaps(time)}`,
    `▸ ${smallCaps(hijri)}`,
    '',
    `]–––––『 *${smallCaps('COMMANDS')}* 』–––––[`,
    '',
    commandSections,
    '',
    smallCaps('Powered By Tsuneyuki')
  ].join('\n');
}
function buildCategoryText(ctx, category, available) {
  const rows = categories[category].filter((name) => available.has(name));
  return [
    `▧──···「 *${smallCaps(labels[category])}* 」`,
    '',
    rows.map((name) => `• ${smallCaps(formatCommand(ctx.config.prefix, name))}`).join('\n'),
    '',
    smallCaps('Powered By Tsuneyuki')
  ].join('\n');
}

export const command = {
  names: ['menu'],
  aliases: ['help'],
  execute: async (ctx) => {
    const available = new Set(commandList().flatMap((item) => item.names || []));
    const requested = String(ctx.args?.[0] || '').toLowerCase();
    const category = Object.keys(categories).find((name) => name.toLowerCase() === requested);

    if (category) {
      await ctx.sock.sendMessage(ctx.jid, { text: buildCategoryText(ctx, category, available) });
      return;
    }

    const text = buildHelpText(ctx, available);
    const senderJid = ctx.senderDisplayJid || ctx.sender;
    const number = cleanNumber(senderJid);
    const mentions = senderJid ? [senderJid] : [];
    const bannerPath = path.join(ctx.config.mediaDir, 'banner.jpg');

    try {
      const banner = await fs.readFile(bannerPath);
      await ctx.sock.sendMessage(ctx.jid, { image: banner, caption: text, mentions });
    } catch {
      await ctx.sock.sendMessage(ctx.jid, { text, mentions });
    }
  }
};
