export const command = {
  names: ['safety', 'anticall'],
  execute: async (ctx) => {
    if (!ctx.isOwner) return ctx.sock.sendMessage(ctx.jid, { text: '❌ Owner only.' });

    const cmd = ctx.text.slice(ctx.config.prefix.length).trim().split(/\s+/)[0].toLowerCase();
    const arg = String(ctx.args?.[0] || '').toLowerCase();

    if (cmd === 'anticall') {
      if (!['on', 'off'].includes(arg)) {
        return ctx.sock.sendMessage(ctx.jid, { text: `📵 AntiCall: ${ctx.config.antiCall ? 'ON' : 'OFF'}\nUsage: ${ctx.config.prefix}anticall on/off` });
      }
      ctx.config.antiCall = arg === 'on';
      return ctx.sock.sendMessage(ctx.jid, { text: `📵 AntiCall ${ctx.config.antiCall ? 'enabled' : 'disabled'}.` });
    }

    if (!['on', 'off'].includes(arg)) {
      return ctx.sock.sendMessage(ctx.jid, {
        text: [
          '🧪 *Under the Hood*',
          '',
          `• Human pacing: ${ctx.config.humanEntropy?.enabled ? 'ON' : 'OFF'}`,
          `• Read delay: ${ctx.config.readMessages ? 'ON' : 'OFF'}`,
          `• Typing indicator: ${ctx.config.autoTyping ? 'ON' : 'OFF'}`,
          `• Send limiter: ${ctx.config.sendLimiter?.enabled ? 'ON' : 'OFF'}`,
          `• AntiCall: ${ctx.config.antiCall ? 'ON' : 'OFF'}`,
          '',
          `Usage: ${ctx.config.prefix}safety on/off`,
          'Note: pacing/rate limiting improves stability but does not guarantee protection from enforcement.'
        ].join('\n')
      });
    }

    const enabled = arg === 'on';
    ctx.config.humanEntropy.enabled = enabled;
    ctx.config.sendLimiter.enabled = enabled;
    ctx.config.autoTyping = enabled;
    ctx.config.readMessages = enabled;
    return ctx.sock.sendMessage(ctx.jid, { text: `🧪 Safety pacing ${enabled ? 'enabled' : 'disabled'}.` });
  }
};
