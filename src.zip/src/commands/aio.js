const API_URL = 'https://api.omegatech.app/api/download/All-downloader-v2';
const MAX_MEDIA_BYTES = 80 * 1024 * 1024;
const REQUEST_TIMEOUT_MS = 60_000;
const USER_AGENT = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 Chrome/139.0.0.0 Mobile Safari/537.36';

function extractUrl(text) {
  const match = String(text || '').match(/https?:\/\/[^\s]+/i);
  return match?.[0]?.replace(/[),.!?]+$/g, '') || '';
}

function asArray(value) {
  if (Array.isArray(value)) return value;
  if (!value) return [];
  return [value];
}

function normalizeMedia(item) {
  if (typeof item === 'string') return { url: item };
  if (!item || typeof item !== 'object') return null;

  const url = item.url || item.download_url || item.downloadUrl || item.link || item.src;
  if (!url || !/^https?:\/\//i.test(String(url))) return null;

  return { ...item, url: String(url) };
}

function uniqueMedia(items) {
  const seen = new Set();
  return items.filter((item) => {
    if (!item?.url || seen.has(item.url)) return false;
    seen.add(item.url);
    return true;
  });
}

function collectMedia(result) {
  return {
    videos: uniqueMedia(asArray(result?.videos).map(normalizeMedia).filter(Boolean)),
    audios: uniqueMedia(asArray(result?.audios).map(normalizeMedia).filter(Boolean)),
    photos: uniqueMedia(asArray(result?.photos).map(normalizeMedia).filter(Boolean))
  };
}

function cleanText(value, fallback = 'Unknown') {
  const text = String(value ?? '').replace(/[\r\n]+/g, ' ').trim();
  return text || fallback;
}

function safeFileName(value, fallback) {
  const name = String(value || fallback)
    .replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_')
    .trim()
    .slice(0, 100);
  return name || fallback;
}

function inferExtension(url, fallback) {
  try {
    const pathname = new URL(url).pathname;
    const match = pathname.match(/\.([a-z0-9]{2,5})$/i);
    if (match) return `.${match[1].toLowerCase()}`;
  } catch {}
  return fallback;
}

async function fetchBuffer(url) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      signal: controller.signal,
      redirect: 'follow',
      headers: { 'user-agent': USER_AGENT }
    });

    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const length = Number(response.headers.get('content-length') || 0);
    if (length > MAX_MEDIA_BYTES) throw new Error('Media exceeds the 80 MB limit');

    const buffer = Buffer.from(await response.arrayBuffer());
    if (buffer.length > MAX_MEDIA_BYTES) throw new Error('Media exceeds the 80 MB limit');

    return {
      buffer,
      contentType: response.headers.get('content-type') || ''
    };
  } finally {
    clearTimeout(timer);
  }
}

function buildCaption(result, type, item) {
  const title = cleanText(result?.title, type === 'audio' ? 'Audio' : type === 'photo' ? 'Image' : 'Video');
  const author = cleanText(result?.author, 'Unknown');
  const source = cleanText(result?.source, 'Unknown');
  const quality = cleanText(item?.quality, 'HD');

  if (type === 'video') {
    return `🎬 *${title}*\n👤 ${author}\n🌐 ${source}\n🎞️ ${quality}`;
  }

  if (type === 'audio') {
    return `🎵 *${title}*\n👤 ${author}\n🌐 ${source}`;
  }

  return `🖼️ *${title}*\n👤 ${author}\n🌐 ${source}`;
}

async function sendVideo(conn, chatId, item, result, index, total) {
  const title = safeFileName(result?.title, 'video');
  const caption = buildCaption(result, 'video', item);

  try {
    await conn.sendMessage(chatId, {
      video: { url: item.url },
      caption,
      mimetype: 'video/mp4'
    });
    return true;
  } catch (firstError) {
    try {
      const { buffer, contentType } = await fetchBuffer(item.url);
      await conn.sendMessage(chatId, {
        video: buffer,
        caption,
        mimetype: contentType || 'video/mp4',
        fileName: `${title}${inferExtension(item.url, '.mp4')}`
      });
      return true;
    } catch (secondError) {
      console.error('[ AIO VIDEO ERROR ]', secondError?.message || firstError?.message || secondError);
      return false;
    }
  }
}

async function sendAudio(conn, chatId, item, result, index, total) {
  const title = safeFileName(result?.title, 'audio');

  try {
    await conn.sendMessage(chatId, {
      audio: { url: item.url },
      mimetype: 'audio/mpeg',
      ptt: false,
      fileName: `${title}.mp3`
    });
    return true;
  } catch (firstError) {
    try {
      const { buffer, contentType } = await fetchBuffer(item.url);
      await conn.sendMessage(chatId, {
        audio: buffer,
        mimetype: contentType || 'audio/mpeg',
        ptt: false,
        fileName: `${title}${inferExtension(item.url, '.mp3')}`
      });
      return true;
    } catch (secondError) {
      console.error('[ AIO AUDIO ERROR ]', secondError?.message || firstError?.message || secondError);
      return false;
    }
  }
}

async function sendPhoto(conn, chatId, item, result, index, total) {
  const caption = buildCaption(result, 'photo', item);

  try {
    await conn.sendMessage(chatId, {
      image: { url: item.url },
      caption
    });
    return true;
  } catch (firstError) {
    try {
      const { buffer } = await fetchBuffer(item.url);
      await conn.sendMessage(chatId, {
        image: buffer,
        caption
      });
      return true;
    } catch (secondError) {
      console.error('[ AIO IMAGE ERROR ]', secondError?.message || firstError?.message || secondError);
      return false;
    }
  }
}

export const command = {
  names: ['aio'],
  aliases: [],

  async execute({ sock, jid, message, text, config }) {
    const url = extractUrl(text.slice(config.prefix.length).trim());

    if (!url) {
      return sock.sendMessage(jid, {
        text: `📥 AIO Downloader\n⏳ Please wait a moment\n\nUsage: ${config.prefix}aio <url>`
      }, { quoted: message });
    }

    // The initial status is the only quoted message. Media messages are sent normally.
    await sock.sendMessage(jid, {
      text: '📥 AIO Downloader\n⏳ Please wait a moment'
    }, { quoted: message });

    try {
      const endpoint = `${API_URL}?action=download&url=${encodeURIComponent(url)}`;
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

      let response;
      try {
        response = await fetch(endpoint, {
          signal: controller.signal,
          headers: {
            accept: 'application/json',
            'user-agent': USER_AGENT
          }
        });
      } finally {
        clearTimeout(timer);
      }

      const raw = await response.text();
      let data;
      try {
        data = JSON.parse(raw);
      } catch {
        throw new Error(`Invalid API response (HTTP ${response.status})`);
      }

      if (!response.ok || !data?.success) {
        throw new Error(data?.message || `API request failed (HTTP ${response.status})`);
      }

      const result = data.data || {};
      const media = collectMedia(result);
      const total = media.videos.length + media.audios.length + media.photos.length;

      if (!total) {
        throw new Error('No downloadable media was returned by the API');
      }

      let index = 0;
      let sent = 0;

      for (const item of media.videos) {
        index++;
        if (await sendVideo(sock, jid, item, result, index, total)) sent++;
      }

      for (const item of media.audios) {
        index++;
        if (await sendAudio(sock, jid, item, result, index, total)) sent++;
      }

      for (const item of media.photos) {
        index++;
        if (await sendPhoto(sock, jid, item, result, index, total)) sent++;
      }

      // Do not send a completion message. The media files are the final messages.
      if (!sent) {
        throw new Error('All media files failed to send');
      }
    } catch (error) {
      console.error('[ AIO ERROR ]', error?.message || error);
      await sock.sendMessage(jid, {
        text: `╭━━━〔 ❌ AIO ERROR 〕━━━╮\n┃ ${cleanText(error?.message, 'Unknown error')}\n╰━━━━━━━━━━━━━━━━━━━━━━╯`
      });
    }
  }
};
