import fs from 'node:fs/promises';
import path from 'node:path';
import { commandList } from '../lib/handler.js';
import { getStats } from '../lib/database.js';
import { smallCaps } from '../lib/utils.js';

const sections = {
  Owner: [
    'broadcast', 'restart', 'public', 'setprefix',
    'safety', 'anticall',
    'ampgrant', 'ampadd', 'ampremove', 'ampreset', 'amplimit',
    'me'
  ],
  Store: [
    'store', 'addcategory', 'delcategory', 'listcategory',
    'setcategorybanner', 'setstorename', 'setstorebanner',
    'addproduct', 'delproduct', 'editproduct', 'storecopy', 'storeaccess'
  ]
};

const labels = {
  Owner: 'ᴏᴡɴᴇʀ ᴄᴏɴᴛʀᴏʟs',
  Store: 'sᴛᴏʀᴇ ᴍᴀɴᴀɢᴇᴍᴇɴᴛ'
};

const formatCommand = (prefix, name) => `${prefix}${String(name).toLowerCase()}`;

function cleanNumber(value) {
  return String(value || '').split('@')[0].split(':')[0].replace(/\D/g, '');
}

function getJakartaDateTime() {
  const now = new Date();
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Jakarta',
    year: 'numeric', month: 'long', day: 'numeric', weekday: 'long',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
  }).formatToParts(now);
  const get = (type) => parts.find((part) => part.type === type)?.value || '';
  const hijri = new Intl.DateTimeFormat('id-ID-u-ca-islamic-umalqura', {
    timeZone: 'Asia/Jakarta', day: 'numeric', month: 'long', year: 'numeric'
  }).format(now);
  return {
    weekday: get('weekday'),
    date: `${get('day')} ${get('month')} ${get('year')}`,
    time: `${get('hour')}:${get('minute')}:${get('second')} WIB`,
    hijri
  };
}

function getJakartaHour() {
  const value = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Jakarta', hour: '2-digit', hour12: false
  }).format(new Date());
  return Number(value === '24' ? '0' : value);
}

function getGreeting(hour) {
  if (hour >= 4 && hour < 11) return 'Good Morning';
  if (hour >= 11 && hour < 15) return 'Good Afternoon';
  if (hour >= 15 && hour < 18) return 'Good Evening';
  return 'Good Night';
}

function buildOwnerMenu(ctx, available) {
  const stats = getStats();
  const { weekday, date, time, hijri } = getJakartaDateTime();
  const senderJid = ctx.senderDisplayJid || ctx.sender;
  const number = cleanNumber(senderJid);
  const pushName = String(ctx.message?.pushName || '').trim();
  const displayName = pushName || number || 'Owner';
  const mentionName = number ? `@${number}` : `@${displayName}`;

  const visibleSections = Object.entries(sections)
    .map(([category, names]) => [category, names.filter((name) => available.has(name))])
    .filter(([, names]) => names.length);

  const commandCount = visibleSections.reduce((total, [, names]) => total + names.length, 0);
  const commandSections = visibleSections.map(([category, names]) => {
    const lines = names.map((name) => `• ${smallCaps(formatCommand(ctx.config.prefix, name))}`).join('\n');
    return `▧──···「 *${smallCaps(labels[category])}* 」\n${lines}`;
  }).join('\n\n');

  return [
    `${smallCaps('Halo,')} ${smallCaps(getGreeting(getJakartaHour()))} ${mentionName} 👑`,
    '',
    `*${smallCaps('OWNER PANEL')} :*`,
    `▸ ${smallCaps('OWNER FEATURES')}: ${commandCount}`,
    `▸ ${smallCaps('STATUS')}: ${smallCaps('OWNER')}`,
    '',
    `*${smallCaps('DATE & TIME')} :*`,
    `▸ ${smallCaps(weekday)}, ${smallCaps(date)}`,
    `▸ ${smallCaps(time)}`,
    `▸ ${smallCaps(hijri)}`,
    '',
    `]–––––『 *${smallCaps('OWNER COMMANDS')}* 』–––––[`,
    '',
    commandSections,
    '',
    smallCaps('Powered By Tsuneyuki')
  ].join('\n');
}

export const command = {
  names: ['menuowner'],
  aliases: ['ownermenu'],
  async execute(ctx) {
    if (!ctx.isOwner) {
      return ctx.sock.sendMessage(ctx.jid, { text: 'Owner only.' });
    }

    const available = new Set(commandList().flatMap((item) => item.names || []));
    const text = buildOwnerMenu(ctx, available);
    const senderJid = ctx.senderDisplayJid || ctx.sender;
    const mentions = senderJid ? [senderJid] : [];
    const bannerPath = path.join(ctx.config.mediaDir, 'banner.jpg');

    try {
      const banner = await fs.readFile(bannerPath);
      return ctx.sock.sendMessage(ctx.jid, { image: banner, caption: text, mentions });
    } catch {
      return ctx.sock.sendMessage(ctx.jid, { text, mentions });
    }
  }
};
