import { db, saveDatabase, getUser, getAmpremiumLimit, setAmpremiumLimit, addAmpremiumLimit } from '../lib/database.js';
import { isOwner, jidNumber } from '../lib/utils.js';

function getMentioned(ctx) {
  return ctx.message?.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || null;
}

function targetFromArgs(ctx) {
  const mentioned = getMentioned(ctx);
  if (mentioned) return mentioned;
  const raw = String(ctx.args[0] || '').replace(/[^0-9]/g, '');
  if (!raw) return null;
  const number = raw.startsWith('0') ? `62${raw.slice(1)}` : raw;
  return `${number}@s.whatsapp.net`;
}

export const command={names:['broadcast','restart','public','setprefix','ampgrant','ampadd','ampremove','ampreset','amplimit'],aliases:[],async execute(ctx){
  if (!ctx.isOwner) return ctx.sock.sendMessage(ctx.jid,{text:'❌ Owner only.'});
  const c=ctx.text.slice(ctx.config.prefix.length).trim().split(/\s+/)[0].toLowerCase();

  if(c==='public'){ const v=(ctx.args[0]||'').toLowerCase(); if(!['on','off'].includes(v)) return ctx.sock.sendMessage(ctx.jid,{text:'Usage: .public on/off'}); db.settings.public=v==='on'; await saveDatabase(); return ctx.sock.sendMessage(ctx.jid,{text:`Public mode: ${v}`}); }
  if(c==='setprefix'){ const p=ctx.args[0]; if(!p||p.length>3) return ctx.sock.sendMessage(ctx.jid,{text:'Usage: .setprefix !'}); ctx.config.prefix=p; return ctx.sock.sendMessage(ctx.jid,{text:`Prefix changed to ${p} for this runtime.`}); }
  if(c==='broadcast'){ const msg=ctx.args.join(' '); if(!msg) return ctx.sock.sendMessage(ctx.jid,{text:'Usage: .broadcast message'}); const groups=await ctx.sock.groupFetchAllParticipating(); let sent=0; for(const id of Object.keys(groups)){await ctx.sock.sendMessage(id,{text:`📢 Broadcast\n\n${msg}`});sent++;} return ctx.sock.sendMessage(ctx.jid,{text:`Broadcast sent to ${sent} groups.`}); }
  if(c==='restart'){ await ctx.sock.sendMessage(ctx.jid,{text:'Restarting bot...'}); process.exit(0); }

  if(['ampgrant','ampadd','ampremove','ampreset','amplimit'].includes(c)) {
    const target = targetFromArgs(ctx);
    if (!target) return ctx.sock.sendMessage(ctx.jid,{text:`❌ Target user was not found.\n\nUse a mention or phone number.\nExample: .${c} @user 5`});

    const current = getAmpremiumLimit(target);
    if (c === 'amplimit') {
      return ctx.sock.sendMessage(ctx.jid,{text:`🎟️ AMP Premium Limit\n\n👤 User: @${jidNumber(target)}\n📊 Limit: ${current}`,mentions:[target]});
    }

    const amount = Math.floor(Number(ctx.args[1]) || 0);
    if (c === 'ampgrant' || c === 'ampadd') {
      if (amount < 1) return ctx.sock.sendMessage(ctx.jid,{text:`❌ The limit amount is invalid.\n\nExample: .${c} @user 5`});
      const next = c === 'ampgrant' ? setAmpremiumLimit(target, amount) : addAmpremiumLimit(target, amount);
      await saveDatabase();
      return ctx.sock.sendMessage(ctx.jid,{text:`✅ AMP Premium limit was successfully ${c === 'ampgrant' ? 'set' : 'added'}.\n\n👤 User: @${jidNumber(target)}\n🎟️ Current limit: ${next}`,mentions:[target]});
    }

    if (c === 'ampremove') {
      if (amount < 1) return ctx.sock.sendMessage(ctx.jid,{text:'❌ The limit amount is invalid.\n\nExample: .ampremove @user 2'});
      const next = setAmpremiumLimit(target, Math.max(0, current - amount));
      await saveDatabase();
      return ctx.sock.sendMessage(ctx.jid,{text:`✅ AMP Premium limit was reduced.\n\n👤 User: @${jidNumber(target)}\n🎟️ Current limit: ${next}`,mentions:[target]});
    }

    if (c === 'ampreset') {
      const next = setAmpremiumLimit(target, 0);
      await saveDatabase();
      return ctx.sock.sendMessage(ctx.jid,{text:`✅ AMP Premium limit was reset.\n\n👤 User: @${jidNumber(target)}\n🎟️ Current limit: ${next}`,mentions:[target]});
    }
  }
}};
