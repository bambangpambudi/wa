import os from 'node:os';
import { formatUptime, jidNumber } from '../lib/utils.js';
export const command={names:['server','speed','memory','date','time','admins'],async execute(ctx){
 const c=ctx.text.slice(ctx.config.prefix.length).trim().split(/\s+/)[0].toLowerCase();
 if(c==='server') return ctx.sock.sendMessage(ctx.jid,{text:`🖥 ${os.platform()} ${os.arch()}\nNode ${process.version}\nCPU ${os.cpus().length} cores\nUptime ${formatUptime(process.uptime())}`});
 if(c==='speed') {const t=Date.now(); await ctx.sock.sendMessage(ctx.jid,{text:'Testing...'}); return ctx.sock.sendMessage(ctx.jid,{text:`⚡ ${Date.now()-t} ms`});}
 if(c==='memory') return ctx.sock.sendMessage(ctx.jid,{text:`RAM RSS: ${Math.round(process.memoryUsage().rss/1024/1024)} MB\nHeap: ${Math.round(process.memoryUsage().heapUsed/1024/1024)} MB`});
 if(c==='date'||c==='time') return ctx.sock.sendMessage(ctx.jid,{text:new Date().toLocaleString('en-US',{dateStyle:c==='date'?'full':undefined,timeStyle:c==='time'?'long':undefined})});
 
 if(c==='admins') {
  if(!ctx.isGroup) return ctx.sock.sendMessage(ctx.jid,{text:'❌ This command is for groups only.'});
  const admins=ctx.participants.filter(p=>p.admin);
  const subject=ctx.metadata?.subject || 'Group';
  const lines=admins.length
    ? admins.map((p,i)=>{
        const jid = p.id || p.jid || p.lid;
        const number = jidNumber(jid);
        const role = p.admin === 'superadmin' ? '👑 Owner' : '🛡️ Admin';
        return `${i+1}. @${number} — ${role}`;
      }).join('\n')
    : 'No group admins found.';
  const mentions=admins.map(p=>p.id || p.jid || p.lid).filter(Boolean);
  return ctx.sock.sendMessage(ctx.jid,{text:[
    `╭━━〔 👥 GROUP ADMINS 〕━━╮`,
    `│ ${subject}`,
    `│ Total : ${admins.length}`,
    '╰━━━━━━━━━━━━━━━━━━━━━━╯',
    '',
    '🛡️ *ADMIN LIST*',
    lines,
    '',
    '▧──···「 *ᴀᴅᴍɪɴ sᴛᴀᴛᴜs* 」',
    `│ ${admins.length ? 'All active group admins are listed above.' : 'No administrators detected.'}`,
    '╰──────────────────────'
  ].join('\n'),mentions});
}
}};
