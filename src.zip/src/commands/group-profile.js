import { downloadMedia } from '../lib/utils.js';

function requireAdmin(ctx) {
  if (!ctx.isAdmin && !ctx.isOwner) throw new Error('Only group admins can use this command.');
}

function requireBotAdmin(ctx) {
  if (!ctx.isBotAdmin) throw new Error('The bot must be a group admin.');
}

function getQuotedImage(message) {
  const context = message.message?.extendedTextMessage?.contextInfo;
  if (!context?.quotedMessage?.imageMessage) return null;
  return {
    key: {
      remoteJid: message.key.remoteJid,
      id: context.stanzaId,
      participant: context.participant
    },
    message: { imageMessage: context.quotedMessage.imageMessage }
  };
}

export const command = {
  names: ['setppgroup'],

  async execute(ctx) {
    if (!ctx.isGroup) throw new Error('This command can only be used in a group.');
    requireAdmin(ctx);
    requireBotAdmin(ctx);

    const currentImage = ctx.message.message?.imageMessage;
    const target = currentImage ? ctx.message : getQuotedImage(ctx.message);

    if (!target) {
      return ctx.sock.sendMessage(ctx.jid, {
        text: `❌ Send an image with ${ctx.config.prefix}setppgroup as the caption, or reply to an image with ${ctx.config.prefix}setppgroup.`
      });
    }

    try {
      const buffer = await downloadMedia(target, 'imageMessage');
      if (!buffer?.length) throw new Error('Failed to download the image.');

      await ctx.sock.updateProfilePicture(ctx.jid, buffer);
      return ctx.sock.sendMessage(ctx.jid, {
        text: '✅ Group profile picture updated successfully.'
      });
    } catch (error) {
      console.error('setppgroup error:', error);
      return ctx.sock.sendMessage(ctx.jid, {
        text: `❌ Failed to update group profile picture: ${error?.message || error}`
      });
    }
  }
};
