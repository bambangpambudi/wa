import fs from 'node:fs/promises';
import path from 'node:path';
import sharp from 'sharp';
import { getGroup, saveDatabase } from '../lib/database.js';
import { downloadMedia, jidNumber } from '../lib/utils.js';

function requireGroup(ctx) {
  if (!ctx.isGroup) throw new Error('This command is for groups only.');
}

function requireAdmin(ctx) {
  requireGroup(ctx);
  if (!ctx.isAdmin && !ctx.isOwner) throw new Error('Admin permission required.');
}

async function requireBotAdmin(ctx) {
  if (ctx.isBotAdmin) return;
  try {
    const fresh = await ctx.sock.groupMetadata(ctx.jid);
    const ownIds = [ctx.sock.user?.id, ctx.sock.user?.lid, ctx.sock.user?.jid, ctx.sock.user?.phoneNumber]
      .filter(Boolean)
      .map((value) => String(value).split(':')[0]);
    const bot = (fresh?.participants || []).find((participant) => {
      const ids = [participant.id, participant.lid, participant.jid]
        .filter(Boolean)
        .map((value) => String(value).split(':')[0]);
      return ids.some((id) => ownIds.includes(id) || id.split('@')[0].replace(/\D/g, '') === String(ctx.sock.user?.id || '').split('@')[0].replace(/\D/g, ''));
    });
    if (['admin', 'superadmin'].includes(bot?.admin)) return;
  } catch {}
  throw new Error('The bot must be a group admin. Please refresh group metadata or promote the bot again.');
}

function targetJid(ctx) {
  const quoted = ctx.message.message?.extendedTextMessage?.contextInfo;
  const mentioned = quoted?.mentionedJid?.[0];
  const participant = quoted?.participant;
  const raw = mentioned || participant || ctx.args[0];
  if (!raw) return null;
  return raw.includes('@') ? raw : `${raw.replace(/\D/g, '')}@s.whatsapp.net`;
}

function mentionsText(participants, text = '') {
  const mentions = participants.map((participant) => participant.id);
  return { text: text || mentions.map((jid) => `@${jidNumber(jid)}`).join(' '), mentions };
}

function getQuotedImage(message) {
  const context = message.message?.extendedTextMessage?.contextInfo;
  if (!context?.quotedMessage?.imageMessage) return null;
  return {
    key: { remoteJid: message.key.remoteJid, id: context.stanzaId, participant: context.participant },
    message: { imageMessage: context.quotedMessage.imageMessage }
  };
}

export const command = {
  names: [
    'groups', 'hidetag', 'mentionall', 'promote', 'demote', 'kick', 'add', 'linkgroup',
    'revoke', 'setname', 'setdesc', 'setwelcome', 'setgoodbye', 'setwelcomeimage',
    'setgoodbyeimage', 'welcome', 'goodbye', 'antilink', 'antitoxic', 'antispam',
    'mute', 'unmute', 'open', 'close'
  ],
  aliases: ['group', 'ginfo', 'groupinfo', 'remove', 'resetlink', 'setsubject'],

  async execute(ctx) {
    const c = ctx.commandName;
    try {
      requireGroup(ctx);
      const settings = getGroup(ctx.jid);

      if (['groups', 'group', 'ginfo', 'groupinfo'].includes(c)) {
        requireAdmin(ctx);
        const admins = ctx.participants.filter((participant) => participant.admin).length;
        return ctx.sock.sendMessage(ctx.jid, { text:
`╭─〔 GROUP INFO 〕
│ Name: ${ctx.metadata?.subject || '-'}
│ Members: ${ctx.participants.length}
│ Admins: ${admins}
│ Welcome: ${settings.welcome ? 'ON' : 'OFF'}
│ Goodbye: ${settings.goodbye ? 'ON' : 'OFF'}
│ AntiLink: ${settings.antilink ? 'ON' : 'OFF'}
│ AntiToxic: ${settings.antitoxic ? 'ON' : 'OFF'}
│ AntiSpam: ${settings.antispam ? 'ON' : 'OFF'}
╰────────────────` });
      }

      if (['mentionall', 'hidetag'].includes(c)) {
        requireAdmin(ctx);
        return ctx.sock.sendMessage(ctx.jid, mentionsText(ctx.participants, ctx.args.join(' ')));
      }

      if (['promote', 'demote', 'kick', 'remove'].includes(c)) {
        requireAdmin(ctx);
        await requireBotAdmin(ctx);
        const target = targetJid(ctx);
        if (!target) throw new Error('Mention or reply to a member.');
        const action = c === 'promote' ? 'promote' : c === 'demote' ? 'demote' : 'remove';
        await ctx.sock.groupParticipantsUpdate(ctx.jid, [target], action);
        return ctx.sock.sendMessage(ctx.jid, { text: `✅ Member ${action} action completed.` });
      }

      if (c === 'add') {
        requireAdmin(ctx);
        await requireBotAdmin(ctx);
        const number = ctx.args[0]?.replace(/\D/g, '');
        if (!number) throw new Error('Usage: .add 628xxxx');
        await ctx.sock.groupParticipantsUpdate(ctx.jid, [`${number}@s.whatsapp.net`], 'add');
        return ctx.sock.sendMessage(ctx.jid, { text: '✅ Member added successfully.' });
      }

      if (c === 'linkgroup') {
        requireAdmin(ctx);
        await requireBotAdmin(ctx);
        const code = await ctx.sock.groupInviteCode(ctx.jid);
        return ctx.sock.sendMessage(ctx.jid, { text: `🔗 https://chat.whatsapp.com/${code}` });
      }

      if (['revoke', 'resetlink'].includes(c)) {
        requireAdmin(ctx);
        await requireBotAdmin(ctx);
        await ctx.sock.groupRevokeInvite(ctx.jid);
        const code = await ctx.sock.groupInviteCode(ctx.jid);
        return ctx.sock.sendMessage(ctx.jid, { text: `✅ Group invite link was reset successfully.\n🔗 https://chat.whatsapp.com/${code}` });
      }

      if (['setname', 'setsubject'].includes(c)) {
        requireAdmin(ctx);
        await requireBotAdmin(ctx);
        const value = ctx.args.join(' ').trim();
        if (!value) throw new Error(`Usage: .${c} <name>`);
        await ctx.sock.groupUpdateSubject(ctx.jid, value);
        return ctx.sock.sendMessage(ctx.jid, { text: '✅ Group name updated successfully.' });
      }

      if (c === 'setdesc') {
        requireAdmin(ctx);
        await requireBotAdmin(ctx);
        const value = ctx.args.join(' ').trim();
        if (!value) throw new Error('Usage: .setdesc <description>');
        await ctx.sock.groupUpdateDescription(ctx.jid, value);
        return ctx.sock.sendMessage(ctx.jid, { text: '✅ Group description updated successfully.' });
      }

      if (['open', 'close'].includes(c)) {
        requireAdmin(ctx);
        await requireBotAdmin(ctx);
        const isClosed = c === 'close';
        await ctx.sock.groupSettingUpdate(ctx.jid, isClosed ? 'announcement' : 'not_announcement');
        return ctx.sock.sendMessage(ctx.jid, { text: `✅ Group is now ${isClosed ? 'closed' : 'open'}.` });
      }

      if (['setwelcomeimage', 'setgoodbyeimage'].includes(c)) {
        requireAdmin(ctx);
        const key = c === 'setwelcomeimage' ? 'welcomeImage' : 'goodbyeImage';
        const label = c === 'setwelcomeimage' ? 'Welcome' : 'Goodbye';
        const value = String(ctx.args[0] || '').toLowerCase();

        if (['reset', 'remove', 'off'].includes(value)) {
          if (settings[key]) {
            try { await fs.unlink(path.join(ctx.config.root, settings[key])); } catch {}
          }
          settings[key] = '';
          await saveDatabase();
          return ctx.sock.sendMessage(ctx.jid, { text: `✅ ${label} banner removed. The default card will be used again.` });
        }

        const currentImage = ctx.message.message?.imageMessage;
        const target = currentImage ? ctx.message : getQuotedImage(ctx.message);
        if (!target) {
          throw new Error(`Send an image with ${ctx.config.prefix}${c} as the caption, or reply to an image with this command.\nReset: ${ctx.config.prefix}${c} reset`);
        }

        const buffer = await downloadMedia(target, 'imageMessage');
        if (!buffer?.length) throw new Error('Failed to download the image.');

        const folder = path.join(ctx.config.dataDir, 'welcome-images');
        await fs.mkdir(folder, { recursive: true });
        const safeJid = ctx.jid.replace(/[^a-zA-Z0-9_-]/g, '_');
        const filename = `${safeJid}-${key}.png`;
        const absolutePath = path.join(folder, filename);
        await sharp(buffer)
          .rotate()
          .resize(1200, 630, { fit: 'cover', position: 'centre' })
          .png()
          .toFile(absolutePath);

        if (settings[key] && settings[key] !== path.relative(ctx.config.root, absolutePath)) {
          try { await fs.unlink(path.join(ctx.config.root, settings[key])); } catch {}
        }

        settings[key] = path.relative(ctx.config.root, absolutePath);
        await saveDatabase();
        return ctx.sock.sendMessage(ctx.jid, {
          text: `✅ ${label} banner saved successfully.\n\n📐 Size: 1200×630\n🖼️ Mode: raw custom banner (no overlay)\n🔄 Reset: ${ctx.config.prefix}${c} reset`
        });
      }

      if (['setwelcome', 'setgoodbye'].includes(c)) {
        requireAdmin(ctx);
        const key = c === 'setwelcome' ? 'welcomeText' : 'goodbyeText';
        const defaultText = c === 'setwelcome'
          ? '👋 Welcome {user} to *{group}*!\nYou are member #{count}.\nType {prefix}menu to view the menu.'
          : '👋 Goodbye {user} from *{group}*. We wish you the best!';
        const value = ctx.args.join(' ').trim();
        if (!value) throw new Error(`Usage: .${c} <message>\nPlaceholders: {user} {name} {group} {count} {prefix}`);
        settings[key] = value.toLowerCase() === 'reset' ? defaultText : value;
        await saveDatabase();
        return ctx.sock.sendMessage(ctx.jid, { text: `✅ ${c === 'setwelcome' ? 'Welcome' : 'Goodbye'} template saved successfully.` });
      }

      if (['welcome', 'goodbye'].includes(c)) {
        requireAdmin(ctx);
        const key = c;
        const arg = String(ctx.args[0] || '').toLowerCase();
        if (!['on', 'off', 'enable', 'disable', '1', '0'].includes(arg)) {
          return ctx.sock.sendMessage(ctx.jid, {
            text: `📌 ${c === 'welcome' ? 'Welcome' : 'Goodbye'}: ${settings[key] ? 'ON' : 'OFF'}\nUsage: .${c} on/off\nSet message: .set${c} <message>`
          });
        }
        settings[key] = ['on', 'enable', '1'].includes(arg);
        await saveDatabase();
        return ctx.sock.sendMessage(ctx.jid, { text: `✅ ${c}: ${settings[key] ? 'ON' : 'OFF'}` });
      }

      if (c === 'antilink') {
        requireAdmin(ctx);
        const arg = String(ctx.args[0] || '').toLowerCase();
        if (arg === 'whitelist') {
          const action = String(ctx.args[1] || '').toLowerCase();
          const domain = String(ctx.args[2] || '').toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0];
          settings.antiLinkWhitelist = Array.isArray(settings.antiLinkWhitelist) ? settings.antiLinkWhitelist : [];
          if (action === 'list') {
            return ctx.sock.sendMessage(ctx.jid, { text: `🔗 AntiLink whitelist:\n${settings.antiLinkWhitelist.length ? settings.antiLinkWhitelist.map((d, i) => `${i + 1}. ${d}`).join('\n') : '(empty)'}` });
          }
          if (!['add', 'del', 'remove'].includes(action) || !domain) {
            throw new Error('Usage: .antilink whitelist add/del <domain>\nExample: .antilink whitelist add youtube.com');
          }
          if (action === 'add' && !settings.antiLinkWhitelist.includes(domain)) settings.antiLinkWhitelist.push(domain);
          if (['del', 'remove'].includes(action)) settings.antiLinkWhitelist = settings.antiLinkWhitelist.filter((d) => d !== domain);
          await saveDatabase();
          return ctx.sock.sendMessage(ctx.jid, { text: `✅ Whitelist: ${settings.antiLinkWhitelist.length ? settings.antiLinkWhitelist.join(', ') : '(empty)'}` });
        }
        if (!['on', 'off', 'enable', 'disable', '1', '0'].includes(arg)) {
          return ctx.sock.sendMessage(ctx.jid, { text: `🔗 AntiLink: ${settings.antilink ? 'ON' : 'OFF'}\nUsage: .antilink on/off\nWhitelist: .antilink whitelist add <domain>` });
        }
        settings.antilink = ['on', 'enable', '1'].includes(arg);
        await saveDatabase();
        return ctx.sock.sendMessage(ctx.jid, { text: `✅ AntiLink: ${settings.antilink ? 'ON' : 'OFF'}` });
      }

      if (c === 'antispam') {
        requireAdmin(ctx);
        const arg = String(ctx.args[0] || '').toLowerCase();
        if (arg === 'time') {
          const seconds = Math.min(3600, Math.max(10, Number(ctx.args[1]) || 60));
          settings.spamMuteSeconds = seconds;
          await saveDatabase();
          return ctx.sock.sendMessage(ctx.jid, { text: `🔇 AntiSpam auto-mute duration: ${seconds} seconds.` });
        }
        if (!['on', 'off', 'enable', 'disable', '1', '0'].includes(arg)) {
          return ctx.sock.sendMessage(ctx.jid, { text: `🛡️ AntiSpam: ${settings.antispam ? 'ON' : 'OFF'}\nMode: the spammer will be muted for ${settings.spamMuteSeconds || 60} seconds.\nUsage: .antispam on/off\nSet duration: .antispam time 60` });
        }
        settings.antispam = ['on', 'enable', '1'].includes(arg);
        await saveDatabase();
        return ctx.sock.sendMessage(ctx.jid, { text: `✅ AntiSpam: ${settings.antispam ? 'ON' : 'OFF'}` });
      }

      if (['antitoxic', 'mute', 'unmute'].includes(c)) {
        requireAdmin(ctx);
        const key = c === 'unmute' ? 'mute' : c;
        const arg = String(ctx.args[0] || '').toLowerCase();
        if (!['on', 'off', 'enable', 'disable', '1', '0'].includes(arg) && c !== 'unmute') {
          throw new Error(`Usage: .${c} on/off`);
        }
        settings[key] = c === 'unmute' ? false : ['on', 'enable', '1'].includes(arg);
        await saveDatabase();
        return ctx.sock.sendMessage(ctx.jid, { text: `✅ ${key}: ${settings[key] ? 'ON' : 'OFF'}` });
      }
    } catch (error) {
      return ctx.sock.sendMessage(ctx.jid, { text: `❌ ${error.message}` });
    }
  }
};
