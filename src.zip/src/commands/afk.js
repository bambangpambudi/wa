import { getUser, saveDatabase } from '../lib/database.js';
import { jidNumber } from '../lib/utils.js';

function getMentioned(ctx) {
  const info = ctx.message.message?.extendedTextMessage?.contextInfo;
  return [...new Set([...(info?.mentionedJid || []), info?.participant].filter(Boolean))];
}

export const command = {
  names: ['afk'],
  aliases: ['unafk'],
  async execute(ctx) {
    const user = getUser(ctx.sender);

    if (ctx.text.slice(ctx.config.prefix.length).trim().toLowerCase().startsWith('unafk')) {
      user.afk = false;
      user.afkReason = '';
      user.afkSince = 0;
      await saveDatabase();
      return ctx.sock.sendMessage(ctx.jid, { text: '✅ AFK status has been disabled.' });
    }

    user.afk = true;
    user.afkReason = ctx.args.join(' ').trim() || 'No reason provided.';
    user.afkSince = Date.now();
    await saveDatabase();
    return ctx.sock.sendMessage(ctx.jid, {
      text: `💤 @${jidNumber(ctx.sender)} is now AFK.\nReason: ${user.afkReason}`,
      mentions: [ctx.sender]
    });
  }
};

export { getMentioned };
