import { getGroupStats, saveDatabase } from '../lib/database.js';
import { jidNumber } from '../lib/utils.js';

function jidCandidates(value) {
  if (!value) return [];
  const raw = String(value);
  const base = raw.split(':')[0];
  const number = base.split('@')[0].replace(/\D/g, '');
  return [raw, base, number].filter(Boolean);
}

function sameJid(a, b) {
  const aa = jidCandidates(a);
  const bb = jidCandidates(b);
  return aa.some((x) => bb.includes(x)) || (jidNumber(a) && jidNumber(a) === jidNumber(b));
}

function getBotIds(sock) {
  return [
    sock.user?.id,
    sock.user?.lid,
    sock.user?.jid,
    sock.user?.phoneNumber
  ].filter(Boolean);
}

function isBotJid(jid, sock) {
  return getBotIds(sock).some((own) => sameJid(jid, own));
}

function resolveCurrentParticipant(statJid, participants) {
  return participants.find((p) =>
    sameJid(statJid, p.id) || sameJid(statJid, p.lid) || sameJid(statJid, p.jid)
  );
}

export const command = {
  names: ['groupstats'],
  aliases: ['gstats'],
  async execute(ctx) {
    if (!ctx.isGroup) throw new Error('This command is for groups only.');

    const stats = getGroupStats(ctx.jid);
    const admins = ctx.participants.filter((p) => p.admin).length;

    // Only show current human members. This removes the bot and stale users
    // that may have left the group from the Top Chatters ranking.
    const top = Object.entries(stats.users || {})
      .filter(([jid]) => !isBotJid(jid, ctx.sock))
      .map(([jid, count]) => ({
        jid,
        count: Number(count) || 0,
        participant: resolveCurrentParticipant(jid, ctx.participants)
      }))
      .filter((item) => item.participant && !isBotJid(item.participant.id || item.jid, ctx.sock))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);

    const humanMessageTotal = Number(stats.humanMessages || 0) || top.reduce((sum, item) => sum + item.count, 0);

    const lines = top.length
      ? top.map((item, i) => `${i + 1}. @${jidNumber(item.participant.id || item.jid)} — ${item.count} msg`).join('\n')
      : 'No member activity yet.';

    await saveDatabase();

    const subject = ctx.metadata?.subject || 'Group';
    const text = [
      '╭━━〔 📊 GROUP STATISTICS 〕━━╮',
      `│ ${subject}`,
      '╰━━━━━━━━━━━━━━━━━━━━━━━━━━╯',
      '',
      '📌 *GROUP OVERVIEW*',
      `│ 👥 Members  : ${ctx.participants.length}`,
      `│ 👑 Admins   : ${admins}`,
      `│ 💬 Messages : ${humanMessageTotal}`,
      `│ 🟢 Joins    : ${stats.joins || 0}`,
      `│ 🔴 Leaves   : ${stats.leaves || 0}`,
      '',
      '🛡️ *MODERATION ACTIVITY*',
      `│ ☣️ Toxic    : ${stats.toxic || 0}`,
      `│ 🔇 Spam     : ${stats.spam || 0}`,
      `│ 🔗 Links    : ${stats.links || 0}`,
      '',
      '🏆 *TOP CHATTERS*',
      lines,
      '',
      '╰── Powered By Tsuneyuki ──╯'
    ].join('\n');

    return ctx.sock.sendMessage(ctx.jid, {
      text,
      mentions: top.map((item) => item.participant.id || item.jid)
    });
  }
};
