const API_URL = 'https://anabot.my.id/api/maker/iqc';
const API_KEY = 'freeApikey';
const REQUEST_TIMEOUT_MS = 60_000;

const DEFAULTS = {
  chatTime: '11:02',
  statusBarTime: '17:01',
  bubbleColor: '#272a2f',
  menuColor: '#272a2f',
  textColor: '#FFFFFF',
  fontName: 'Arial',
  signalName: 'Telkomsel'
};

function clean(value, fallback = '') {
  const text = String(value ?? '').trim();
  return text || fallback;
}

function parseArguments(rawText) {
  const parts = String(rawText || '')
    .split('|')
    .map((part) => part.trim());

  return {
    text: clean(parts[0]),
    chatTime: clean(parts[1], DEFAULTS.chatTime),
    statusBarTime: clean(parts[2], DEFAULTS.statusBarTime),
    bubbleColor: clean(parts[3], DEFAULTS.bubbleColor),
    menuColor: clean(parts[4], DEFAULTS.menuColor),
    textColor: clean(parts[5], DEFAULTS.textColor),
    fontName: clean(parts[6], DEFAULTS.fontName),
    signalName: clean(parts[7], DEFAULTS.signalName)
  };
}

function extractCommandText(text, prefix) {
  let value = String(text || '').trim();
  const commandPrefix = `${prefix}iqc`;

  if (value.toLowerCase().startsWith(commandPrefix.toLowerCase())) {
    value = value.slice(commandPrefix.length).trim();
  }

  return value;
}

async function requestIqc(params) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    // AnaBot IQC returns the generated image directly (HTTP 200), not a JSON
    // object containing an image URL.
    const query = new URLSearchParams({
      text: params.text,
      chatTime: params.chatTime,
      statusBarTime: params.statusBarTime,
      bubbleColor: params.bubbleColor,
      menuColor: params.menuColor,
      textColor: params.textColor,
      fontName: params.fontName,
      signalName: params.signalName,
      apikey: API_KEY
    });

    const response = await fetch(`${API_URL}?${query.toString()}`, {
      method: 'GET',
      signal: controller.signal,
      headers: {
        accept: 'image/*, application/json;q=0.9, */*;q=0.8',
        'user-agent': 'Artex-Bot/4.14.17'
      }
    });

    const contentType = response.headers.get('content-type') || '';
    const buffer = Buffer.from(await response.arrayBuffer());

    if (!response.ok) {
      let detail = '';
      if (contentType.includes('application/json')) {
        try {
          const data = JSON.parse(buffer.toString('utf8'));
          detail = data?.message || data?.error || data?.msg || '';
        } catch {}
      } else {
        detail = buffer.toString('utf8').trim().slice(0, 300);
      }
      throw new Error(detail || `API request failed (HTTP ${response.status})`);
    }

    if (!buffer.length) {
      throw new Error('The IQC API returned an empty image.');
    }

    // Some API errors can still arrive with HTTP 200. Detect those before
    // sending the response as an image.
    if (contentType.includes('application/json') || contentType.startsWith('text/')) {
      const body = buffer.toString('utf8').trim();
      let message = body;
      try {
        const data = JSON.parse(body);
        message = data?.message || data?.error || data?.msg || body;
      } catch {}
      throw new Error(message || `Unexpected API response (HTTP ${response.status})`);
    }

    const mimetype = contentType.split(';')[0].trim() || 'image/png';
    return { buffer, mimetype };
  } finally {
    clearTimeout(timer);
  }
}

export const command = {
  names: ['iqc'],
  aliases: ['iphonequotedchat'],

  async execute({ sock, jid, message, text, config }) {
    const input = extractCommandText(text, config.prefix);
    const params = parseArguments(input);

    if (!params.text) {
      return sock.sendMessage(jid, {
        text: [
          '╭━━━〔 📱 IPHONE QUOTED CHAT 〕━━━╮',
          '┃',
          `┃ Usage: ${config.prefix}iqc <text>`,
          '┃',
          '┃ Optional format:',
          `┃ ${config.prefix}iqc <text> | chatTime | statusBarTime | bubbleColor | menuColor | textColor | fontName | signalName`,
          '┃',
          '┃ Example:',
          `┃ ${config.prefix}iqc Hello | 11:02 | 17:01 | #272a2f | #272a2f | #FFFFFF | Arial | Telkomsel`,
          '┃',
          '╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯'
        ].join('\n')
      }, { quoted: message });
    }

    await sock.sendMessage(jid, {
      text: '📱 Iphone Quoted Chat\n⏳ Please wait a moment'
    }, { quoted: message });

    try {
      const { buffer, mimetype } = await requestIqc(params);
      await sock.sendMessage(jid, {
        image: buffer,
        mimetype
      });
    } catch (error) {
      console.error('[ IQC ERROR ]', error?.message || error);
      await sock.sendMessage(jid, {
        text: [
          '╭━━━〔 ❌ IQC ERROR 〕━━━╮',
          `┃ ${clean(error?.message, 'Unknown error')}`,
          '╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯'
        ].join('\n')
      });
    }
  }
};
