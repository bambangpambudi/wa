// AMP Premium dengan sistem limit owner dan custom order ID
// Custom Order ID: ArtexAM-byTsuneyuki

import axios from 'axios';
import crypto from 'crypto';

// ============ KONFIGURASI ============
const cfg = {
  key: 'AIzaSyDtG1AU22ErnQD60AzBAcaknySiz9_CEq0',
  idt: 'https://www.googleapis.com/identitytoolkit/v3/relyingparty',
  stk: 'https://securetoken.googleapis.com/v1/token',
  vfy: 'https://us-central1-alight-creative.cloudfunctions.net/verifyPurchase'
};

const PENDING_TTL = 10 * 60 * 1000;
const pending = new Map();

// ============ HEADERS ============
const dip = () => [crypto.randomInt(1,255), crypto.randomInt(0,255), crypto.randomInt(0,255), crypto.randomInt(1,255)].join('.');

const sp = h => ({
  ...h,
  'x-forwarded-for': dip(),
  'x-real-ip': dip(),
  'client-ip': dip(),
  'x-client-ip': dip(),
  'x-originating-ip': dip(),
  'x-cluster-client-ip': dip()
});

const h1 = {
  'content-type': 'application/json',
  'x-android-package': 'com.alightcreative.motion',
  'x-android-cert': 'ECA6BF91B8715A6F810ED0BBFC65B6CD578F52A8',
  'user-agent': 'dalvik/2.1.0 (linux; u; android 15; 23127pn0cc build/bp1a.250505.005)'
};

const h2 = {
  'content-type': 'application/json; charset=utf-8',
  'user-agent': 'okhttp/3.12.1',
  'accept-encoding': 'gzip'
};

// ============ FUNGSI UTILITY ============
function extractText(message) {
  const m = message?.message || {};
  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    ''
  ).trim();
}

function extractMagicLink(text) {
  const source = String(text || '').trim();
  const match = source.match(/https:\/\/alight-creative\.firebaseapp\.com\/__\/auth\/links\?link=[^\s<>"']+/i);
  if (!match) return null;
  return match[0].replace(/[),.;!?]+$/g, '');
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function isMagicLink(link) {
  try {
    const url = new URL(link);
    return (
      url.protocol === 'https:' &&
      url.hostname === 'alight-creative.firebaseapp.com' &&
      url.pathname === '/__/auth/links' &&
      url.searchParams.has('link')
    );
  } catch {
    return false;
  }
}

function code(raw) {
  if (!raw) return null;
  let s = String(raw).replace(/&/g, '&');
  try { s = decodeURIComponent(s); } catch {}
  try {
    const u = new URL(s);
    let c = u.searchParams.get('oobCode');
    if (!c) {
      const n = u.searchParams.get('link') || u.searchParams.get('q') || u.searchParams.get('url');
      if (n) {
        try { c = new URL(n).searchParams.get('oobCode'); } catch {}
      }
    }
    if (c) return c.replace(/[^a-zA-Z0-9_-]/g, '');
  } catch {}
  const m = s.match(/oobCode=([a-zA-Z0-9_-]+)/i);
  if (m) return m[1];
  const t = raw.trim();
  if (/^[a-zA-Z0-9_-]{10,}$/.test(t) && !t.includes('://')) return t;
  return null;
}

function getResultData(result) {
  return result?.data || result?.result || result;
}

function resultSucceeded(result) {
  const data = getResultData(result);
  if (result?.success === true || data?.success === true) return true;
  if (data?.premium === true) return true;
  if (typeof data?.membershipStatus === 'string' && /active|premium/i.test(data.membershipStatus)) return true;
  return false;
}

function formatDate(value) {
  if (!value) return '-';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
}

// ============ FUNGSI API ALIGHT MOTION ============
async function sendMagicLink(email) {
  const c1 = { identifier: email, continueUri: 'http://localhost' };
  const c2 = {
    requestType: 6,
    email: email,
    androidInstallApp: true,
    canHandleCodeInApp: true,
    continueUrl: 'https://alightcreative.com?ui_sid=0366624874&ui_sd=0',
    iosBundleId: 'com.alightcreative.motion',
    androidPackageName: 'com.alightcreative.motion',
    androidMinimumVersion: '585',
    clientType: 'CLIENT_TYPE_ANDROID'
  };
  try {
    await axios.post(`${cfg.idt}/createAuthUri?key=${cfg.key}`, c1, { headers: sp(h1) });
    const r = await axios.post(`${cfg.idt}/getOobConfirmationCode?key=${cfg.key}`, c2, { headers: sp(h1) });
    return { success: true, data: r.data };
  } catch (e) {
    const d = e.response?.data;
    return { success: false, message: d ? (typeof d === 'object' ? JSON.stringify(d) : String(d)) : e.message };
  }
}

async function verifyAndActivate(email, magicLink) {
  const oobCode = code(magicLink);
  if (!oobCode) return { success: false, message: 'Code tidak ditemukan' };
  
  try {
    // Login dengan email link
    const authRes = await axios.post(`${cfg.idt}/emailLinkSignin?key=${cfg.key}`, {
      email: email,
      oobCode: oobCode,
      clientType: 'CLIENT_TYPE_ANDROID'
    }, { headers: sp(h1) });
    
    const idToken = authRes.data.idToken;
    
    // 🔥 CUSTOM ORDER ID
    const orderId = 'ArtexAM-byTsuneyuki-' + crypto.randomBytes(6).toString('hex');
    
    // Verifikasi purchase
    const verifyRes = await axios.post(cfg.vfy, {
      data: {
        productId: 'am.full.sub.annual.19q4',
        token: 'mmgaobamlahbbeccfplmbkbb.AO-J1OzqG0or_GJJIx-ms8GrTm-jaglCRfhQSRPUZKpl2YspYS-oN7_94uv8RC5vQbvd_Ios2pPDStZ2n7F0hLE3FiOU7HS3R6Fquulv5xLXFECSv4ctElw',
        skuType: 'subs',
        orderId: orderId
      }
    }, {
      headers: {
        ...h2,
        authorization: 'Bearer ' + idToken,
        'firebase-instance-id-token': 'cSDnCyp3T-uwp07z3tL86T:APA91bFkmvvsHw5nnqa1SBFci-99DRsKClLiETdRrVcJjS5yBx1v_FbCb1d8WhBuea_zmwnYBktyTIzcRhN4b6uNOUur9wPc0gKXmJDoZic0LhNq5V2s0xI'
      }
    });
    
    return {
      success: true,
      data: verifyRes.data,
      orderId: orderId,
      email: email
    };
  } catch (e) {
    const d = e.response?.data;
    return { success: false, message: d ? (typeof d === 'object' ? JSON.stringify(d) : String(d)) : e.message };
  }
}

// ============ SISTEM LIMIT (DARI KODE 1) ============
export function getAmpremiumAccess(ctx) {
  if (ctx.isOwner) return { allowed: true, owner: true, limit: Infinity };
  const limit = ctx.getUser ? Math.max(0, Number(ctx.getUser()?.ampremiumLimit || 0)) : 0;
  return { allowed: limit > 0, owner: false, limit };
}

export function consumeAmpremium(ctx) {
  if (ctx.isOwner) return true;
  const user = ctx.getUser?.();
  if (!user) return false;
  const limit = Math.max(0, Number(user.ampremiumLimit || 0));
  if (limit < 1) return false;
  user.ampremiumLimit = limit - 1;
  return true;
}

// ============ COMMAND ============
export const command = {
  names: ['ampremium'],
  aliases: [],
  description: 'Activate AMP Premium with custom order ID ArtexAM-byTsuneyuki',
  category: 'Tools',

  async execute(ctx) {
    const access = getAmpremiumAccess(ctx);
    if (!access.allowed) {
      await ctx.sock.sendMessage(ctx.jid, {
        text: '❌ You do not have an AMP Premium limit.\n\nThis feature is available only to the Owner or users who have been granted a limit by the Owner.'
      });
      return;
    }

    const email = String(ctx.args[0] || '').trim().toLowerCase();
    if (!isValidEmail(email)) {
      await ctx.sock.sendMessage(ctx.jid, {
        text: '❌ Invalid email format.\n\nUsage:\n.ampremium email@gmail.com\n\nUse an email address that you own and can access.'
      });
      return;
    }

    const key = `${ctx.jid}:${ctx.sender}`;

    try {
      await ctx.sock.sendMessage(ctx.jid, { text: `⏳ Sending Magic Link request for ${email}...` });

      const sendRes = await sendMagicLink(email);
      if (!sendRes.success) {
        throw new Error(sendRes.message || 'Failed to send magic link');
      }

      // Consume limit hanya setelah berhasil kirim link
      if (!consumeAmpremium(ctx)) {
        await ctx.sock.sendMessage(ctx.jid, { 
          text: '❌ Your AMP Premium limit has been exhausted. The request cannot continue.' 
        });
        return;
      }
      await ctx.saveDatabase();

      pending.set(key, { 
        email, 
        createdAt: Date.now(), 
        expiresAt: Date.now() + PENDING_TTL 
      });

      await ctx.sock.sendMessage(ctx.jid, {
        text: ctx.isOwner
          ? `✅ Email ${email} was processed successfully.\n\n📩 The Magic Link has been sent to that email address.\nOpen your email, then send the Magic Link to this chat.\n\n👑 Owner: unlimited limit.\n🆔 Order ID: ArtexAM-byTsuneyuki-xxxxxx`
          : `✅ Email ${email} was processed successfully.\n\n📩 The Magic Link has been sent to that email address.\nOpen your email, then send the Magic Link to this chat.\n\n🎟️ Remaining AMP Premium limit: ${ctx.getUser()?.ampremiumLimit || 0}\n🆔 Order ID: ArtexAM-byTsuneyuki-xxxxxx`
      });
    } catch (error) {
      await ctx.sock.sendMessage(ctx.jid, { 
        text: `❌ Failed to send the Magic Link.\n\n${error?.message || String(error)}` 
      });
    }
  },

  async onMessage({ sock, message, jid, sender, senderDisplayJid, config }) {
    const key = `${jid}:${sender}`;
    const state = pending.get(key);
    if (!state) return false;

    if (state.expiresAt <= Date.now()) {
      pending.delete(key);
      await sock.sendMessage(jid, { 
        text: '⌛ The AMP Premium session has expired. Run .ampremium email@example.com again.' 
      });
      return true;
    }

    const text = extractText(message);
    const magicLink = extractMagicLink(text);
    if (!magicLink || !isMagicLink(magicLink)) return false;

    try {
      await sock.sendMessage(jid, { text: '⏳ Verifying and activating premium...' });
      
      const verifyRes = await verifyAndActivate(state.email, magicLink);
      
      if (!verifyRes.success) {
        throw new Error(verifyRes.message || 'Verification failed');
      }

      pending.delete(key);
      
      await sock.sendMessage(jid, {
        text: `✅ *PREMIUM ACTIVATED!*\n\n📧 Email: ${state.email}\n🆔 Order ID: ${verifyRes.orderId}\n⭐ Status: Active\n📅 Valid until: ${formatDate(verifyRes.data?.validUntil)}\n\n🎉 Alight Motion Premium has been activated with custom order ID: ArtexAM-byTsuneyuki`
      });
    } catch (error) {
      await sock.sendMessage(jid, {
        text: `❌ AMP PREMIUM VERIFICATION FAILED\n\n${error?.message || String(error)}\n\nMake sure the Magic Link is the complete link from the email and has not already been used.`
      });
    }
    return true;
  },
};