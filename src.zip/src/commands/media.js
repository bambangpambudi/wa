import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import sharp from 'sharp';
import ffmpegPath from 'ffmpeg-static';
import webpmux from 'node-webpmux';
import { downloadMedia, unwrapMessage } from '../lib/utils.js';

const AUTHOR = 'By Tsuneyuki';
const PACK = 'Artex Sticker';
const MAX_VIDEO_SECONDS = 10;

function buildStickerExif() {
  const metadata = {
    'sticker-pack-id': 'tsuneyuki-sticker',
    'sticker-pack-name': PACK,
    'sticker-pack-publisher': AUTHOR,
    emojis: []
  };
  const json = Buffer.from(JSON.stringify(metadata), 'utf8');
  const header = Buffer.from([
    0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00,
    0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x16, 0x00, 0x00, 0x00
  ]);
  const exif = Buffer.concat([header, json]);
  exif.writeUIntLE(json.length, 14, 4);
  return exif;
}

async function addStickerMetadata(webpBuffer) {
  const image = new webpmux.Image();
  await image.load(webpBuffer);
  image.exif = buildStickerExif();
  return image.save(null);
}

function escapeXml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function wrapText(text, maxChars = 13, maxLines = 8) {
  const words = String(text).trim().split(/\s+/).filter(Boolean);
  const lines = [];
  let line = '';

  for (const word of words) {
    // Very long words are split into safe chunks so they can never overflow the frame.
    if (word.length > maxChars) {
      if (line) {
        lines.push(line);
        line = '';
      }
      for (let i = 0; i < word.length; i += maxChars) {
        lines.push(word.slice(i, i + maxChars));
      }
      continue;
    }

    const next = line ? `${line} ${word}` : word;
    if (next.length > maxChars) {
      if (line) lines.push(line);
      line = word;
    } else {
      line = next;
    }
  }

  if (line) lines.push(line);
  return lines.slice(0, maxLines);
}

async function createBratSticker(text, animated = false) {
  const words = String(text).trim().split(/\s+/).filter(Boolean);
  const lines = wrapText(text);
  const lineCount = Math.max(lines.length, 1);

  // Keep text comfortably inside the 512x512 sticker canvas.
  const fontSize = lineCount <= 2 ? 68 : lineCount <= 4 ? 58 : lineCount <= 6 ? 50 : 44;
  const lineHeight = Math.round(fontSize * 1.12);
  const height = 512;
  const sidePadding = 42;
  const textWidth = 512 - sidePadding * 2;
  const textCenter = 256;

  // Map every source word to the wrapped line where it appears.
  const wrappedWordLines = [];
  let wordIndex = 0;
  for (const line of lines) {
    const lineWords = line.split(/\s+/).filter(Boolean);
    wrappedWordLines.push(lineWords.map(() => wordIndex++));
  }

  function buildVisibleLines(visibleCount) {
    let sourceIndex = 0;
    return wrappedWordLines.map((lineWordIndexes) => lineWordIndexes.map(() => {
      const visible = sourceIndex < visibleCount;
      const word = words[sourceIndex];
      sourceIndex += 1;
      return visible ? word : null;
    }));
  }

  function renderSvg(visibleCount, frame = 0) {
    const visibleLines = buildVisibleLines(visibleCount);
    const visibleLineCount = Math.max(visibleLines.filter(line => line.some(Boolean)).length, 1);
    const totalHeight = visibleLineCount * lineHeight;
    const startY = Math.max(fontSize + 8, Math.round((height - totalHeight) / 2 + fontSize * 0.78));
    const offsetX = animated ? Math.round(Math.sin(frame * 0.55) * 2) : 0;
    const offsetY = animated ? Math.round(Math.cos(frame * 0.5) * 1.5) : 0;

    let lineIndex = 0;
    const textParts = [];

    for (const lineWords of visibleLines) {
      const visibleWords = lineWords.filter(Boolean);
      if (!visibleWords.length) continue;

      const isLastVisibleLine = lineIndex === visibleLineCount - 1;
      const isCompleteLine = visibleWords.length === lineWords.length;
      const justify = !isLastVisibleLine && isCompleteLine && visibleWords.length > 1;
      const content = visibleWords.map(escapeXml).join(' ');
      const y = startY + lineIndex * lineHeight + offsetY;

      if (justify) {
        textParts.push(
          `<text x="${sidePadding + offsetX}" y="${y}" text-anchor="start" textLength="${textWidth}" lengthAdjust="spacing">${content}</text>`
        );
      } else {
        textParts.push(
          `<text x="${textCenter + offsetX}" y="${y}" text-anchor="middle">${content}</text>`
        );
      }
      lineIndex += 1;
    }

    return `<?xml version="1.0"?><svg width="512" height="512" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><rect width="512" height="512" fill="white"/><g font-family="Arial,Helvetica,sans-serif" font-size="${fontSize}" font-weight="900" fill="#111">${textParts.join('')}</g></svg>`;
  }

  if (!animated) {
    return sharp(Buffer.from(renderSvg(words.length))).png().webp({ quality: 92 }).toBuffer();
  }

  // WhatsApp animated stickers are animated WebP, not literal GIF files.
  // Reveal one source word at a time, then keep the complete text visible.
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'brat-frames-'));
  const inputPattern = path.join(dir, 'frame-%03d.png');
  const output = path.join(dir, 'brat.webp');

  try {
    const revealFrames = Math.max(words.length, 1);
    const holdFrames = Math.max(8, Math.ceil(revealFrames * 0.45));
    const frameCount = revealFrames + holdFrames;

    for (let i = 0; i < frameCount; i++) {
      const visibleCount = Math.min(i + 1, words.length);
      const svg = renderSvg(visibleCount, i);
      const frame = await sharp(Buffer.from(svg)).png().toBuffer();
      await fs.writeFile(path.join(dir, `frame-${String(i).padStart(3, '0')}.png`), frame);
    }

    await runFfmpeg([
      '-y', '-framerate', '8', '-i', inputPattern,
      '-vf', 'scale=512:512:flags=lanczos',
      '-c:v', 'libwebp', '-lossless', '0', '-q:v', '70',
      '-loop', '0', '-an', output
    ]);
    return await fs.readFile(output);
  } finally {
    await fs.rm(dir, { recursive: true, force: true });
  }
}
function runFfmpeg(args) {
  return new Promise((resolve, reject) => {
    const p = spawn(ffmpegPath, args);
    let err = '';
    p.stderr.on('data', (d) => { err += d; });
    p.on('close', (code) => code === 0
      ? resolve()
      : reject(new Error(err.slice(-1000) || `ffmpeg exited ${code}`)));
    p.on('error', reject);
  });
}

async function videoToWebp(input) {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'wa-sticker-'));
  const output = path.join(dir, 'sticker.webp');

  try {
    await runFfmpeg([
      '-y', '-i', input, '-t', String(MAX_VIDEO_SECONDS),
      '-vf', 'scale=512:512:force_original_aspect_ratio=decrease,fps=12,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=white',
      '-c:v', 'libwebp', '-lossless', '0', '-q:v', '70', '-loop', '0', '-an', output
    ]);
    return await fs.readFile(output);
  } finally {
    await fs.rm(dir, { recursive: true, force: true });
  }
}

function quotedMedia(message) {
  const ctx = message.message?.extendedTextMessage?.contextInfo;
  if (!ctx?.quotedMessage) return null;

  return unwrapMessage({
    key: {
      remoteJid: message.key.remoteJid,
      id: ctx.stanzaId,
      participant: ctx.participant
    },
    message: ctx.quotedMessage
  });
}

function detectMedia(msg) {
  const m = msg.message || {};
  if (m.imageMessage) return 'imageMessage';
  if (m.videoMessage) return 'videoMessage';
  if (m.stickerMessage) return 'stickerMessage';
  return null;
}

function getQuotedViewOnce(message) {
  const ctx = message.message?.extendedTextMessage?.contextInfo;
  if (!ctx?.quotedMessage) return null;

  const quoted = unwrapMessage({
    key: {
      remoteJid: message.key.remoteJid,
      id: ctx.stanzaId,
      participant: ctx.participant
    },
    message: ctx.quotedMessage
  });

  const type = detectMedia(quoted);
  if (!type || type === 'stickerMessage') return null;

  return { quoted, type };
}


export const command = {
  names: ['sticker', 'brat', 'bratgif', 'toimg', 'viewonce'],
  aliases: ['s', 'bratsticker'],

  async execute({ sock, jid, message, text, config, args }) {
    const cmd = text.slice(config.prefix.length).trim().split(/\s+/)[0].toLowerCase();

    if (cmd === 'brat' || cmd === 'bratsticker' || cmd === 'bratgif') {
      const wantsGif = cmd === 'bratgif' || /^gif$/i.test(args[0] || '');
      const valueArgs = wantsGif && /^gif$/i.test(args[0] || '') ? args.slice(1) : args;
      const value = valueArgs.join(' ').trim();
      if (!value) {
        return sock.sendMessage(
          jid,
          { text: `Usage: ${config.prefix}brat <text>\nAnimated: ${config.prefix}brat gif <text> or ${config.prefix}bratgif <text>` },
          { quoted: message }
        );
      }

      const sticker = await createBratSticker(value, wantsGif);
      const stickerWithMetadata = await addStickerMetadata(sticker);
      return sock.sendMessage(
        jid,
        { sticker: stickerWithMetadata },
        { quoted: message }
      );
    }

    if (cmd === 'viewonce') {
      const target = getQuotedViewOnce(message);
      if (!target) {
        return sock.sendMessage(jid, {
          text: `Reply to a view-once image or video with ${config.prefix}viewonce.`
        });
      }

      const input = await downloadMedia(target.quoted, target.type);
      const media = target.type === 'imageMessage'
        ? { image: input, caption: target.quoted.message?.imageMessage?.caption || '' }
        : { video: input, caption: target.quoted.message?.videoMessage?.caption || '' };

      return sock.sendMessage(jid, media);
    }

    const target = quotedMedia(message) || message;
    const type = detectMedia(target);

    if (cmd === 'toimg') {
      return sock.sendMessage(
        jid,
        { text: 'Use .sticker on an image, GIF, or video. Sticker-to-image conversion is not enabled in this build.' },
        { quoted: message }
      );
    }

    if (!type || type === 'stickerMessage') {
      return sock.sendMessage(
        jid,
        { text: `Reply to an image, GIF, or video with ${config.prefix}sticker.` },
        { quoted: message }
      );
    }

    const input = await downloadMedia(target, type);
    const webp = type === 'imageMessage'
      ? await sharp(input)
          .resize(512, 512, { fit: 'contain', background: '#ffffff' })
          .webp({ quality: 90 })
          .toBuffer()
      : await videoToWebp(input);
    const stickerWithMetadata = await addStickerMetadata(webp);

    return sock.sendMessage(
      jid,
      { sticker: stickerWithMetadata },
      { quoted: message }
    );
  }
};
