import { isOwner } from '../lib/utils.js';
export const command = { names: ['calc','base64','quote'], async execute({ sock, jid, args, text, config }) {
  const cmd = text.slice(config.prefix.length).trim().split(/\s+/)[0].toLowerCase();
  if (cmd === 'calc') {
    const expr = args.join(' ');
    if (!expr || !/^[0-9+\-*/().%\s]+$/.test(expr)) return sock.sendMessage(jid,{text:'Usage: .calc 12*(5+2)'});
    try { return sock.sendMessage(jid,{text:`🧮 ${expr} = ${Function(`"use strict"; return (${expr})`)()}`}); } catch { return sock.sendMessage(jid,{text:'Invalid expression.'}); }
  }
  if (cmd === 'base64') return sock.sendMessage(jid,{text:args.length ? Buffer.from(args.join(' ')).toString('base64') : 'Usage: .base64 text'});
  if (cmd === 'quote') { const q=['Discipline beats motivation.','Build systems, not wishes.','Small consistent actions compound.','Clarity comes from execution.']; return sock.sendMessage(jid,{text:`💬 ${q[Math.floor(Math.random()*q.length)]}`}); }
} };
