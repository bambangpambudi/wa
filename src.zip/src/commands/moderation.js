import { getGroup, saveDatabase } from '../lib/database.js';
export const command={names:['warn','unwarn','warnings','resetwarn'],async execute(ctx){
 if(!ctx.isGroup)return ctx.sock.sendMessage(ctx.jid,{text:'This command is for groups only.'}); if(!ctx.isAdmin&&!ctx.isOwner)return ctx.sock.sendMessage(ctx.jid,{text:'Admin permission required.'});
 const c=ctx.text.slice(ctx.config.prefix.length).trim().split(/\s+/)[0].toLowerCase(); const t=ctx.message.message?.extendedTextMessage?.contextInfo?.participant||ctx.message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
 if(!t)return ctx.sock.sendMessage(ctx.jid,{text:'Reply to or mention a member.'}); const {getUser}=await import('../lib/database.js'); const u=getUser(t);
 if(c==='warn'){u.warns++;await saveDatabase();return ctx.sock.sendMessage(ctx.jid,{text:`⚠️ Warns: ${u.warns}/3`});}
 if(c==='unwarn'){u.warns=Math.max(0,u.warns-1);await saveDatabase();return ctx.sock.sendMessage(ctx.jid,{text:`Warns: ${u.warns}/3`});}
 if(c==='resetwarn'){u.warns=0;await saveDatabase();return ctx.sock.sendMessage(ctx.jid,{text:'Warnings reset.'});}
 if(c==='warnings')return ctx.sock.sendMessage(ctx.jid,{text:`Warnings: ${u.warns}`});
}};
