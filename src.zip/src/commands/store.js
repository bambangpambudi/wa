import fs from 'node:fs/promises';
import path from 'node:path';
import sharp from 'sharp';
import { getSqlite, getGroup, saveDatabase, hasStoreAccess, addStoreAccess, removeStoreAccess, listStoreAccess } from '../lib/database.js';
import { downloadMedia } from '../lib/utils.js';

const money = (value) => `Rp ${Number(value || 0).toLocaleString('id-ID')}`;
const slugify = (value) => String(value || '').trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 64);
const safeFile = (value) => String(value).replace(/[^a-zA-Z0-9_-]/g, '_');

function requireGroup(ctx) { if (!ctx.isGroup) throw new Error('This command is for groups only.'); }
function requireAdmin(ctx) { requireGroup(ctx); if (!ctx.isAdmin && !ctx.isOwner) throw new Error('Admin permission required.'); }

function targetUserJid(ctx) {
  const mentioned = ctx.message?.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
  if (mentioned) return String(mentioned).split(':')[0];
  const raw = String(ctx.args?.[1] || ctx.args?.[0] || '').replace(/[^0-9]/g, '');
  if (!raw) return null;
  const number = raw.startsWith('0') ? `62${raw.slice(1)}` : raw;
  return `${number}@s.whatsapp.net`;
}

function displayJid(jid) { return String(jid || '').split('@')[0].split(':')[0]; }

function requireStoreAccess(ctx) {
  if (ctx.isOwner) return;
  const userJid = String(ctx.senderDisplayJid || ctx.sender || '').split(':')[0];
  if (!hasStoreAccess(userJid)) {
    throw new Error('Store access denied. Ask the owner to grant you Store access.');
  }
}
function db() { return getSqlite(); }
function storeGroupJid(jid) { return String(jid || '').trim().split(':')[0]; }
function ensureStoreGroup(jid) {
  const key = storeGroupJid(jid);
  if (!key) throw new Error('Invalid group JID.');
  const group = getGroup(key);
  db().prepare('INSERT OR IGNORE INTO groups(jid,data) VALUES(?,?)').run(key, JSON.stringify(group));
  return key;
}
function category(ctx, value) {
  const raw = String(value || '').trim();
  if (!raw) return null;
  const key = ensureStoreGroup(ctx.jid);

  // Category commands support both the category slug/name and its numeric
  // position from .listcategory, e.g. .setcategorybanner 2.
  if (/^\d+$/.test(raw)) {
    const index = Number(raw);
    if (index >= 1) {
      return db().prepare(
        'SELECT * FROM store_categories WHERE group_jid=? ORDER BY id LIMIT 1 OFFSET ?'
      ).get(key, index - 1) || null;
    }
  }

  const slug = slugify(raw);
  if (!slug) return null;
  return db().prepare('SELECT * FROM store_categories WHERE group_jid=? AND slug=?').get(key, slug) || null;
}
function parsePrice(value) {
  const digits = String(value || '').replace(/[^0-9]/g, '');
  if (!digits) throw new Error('Price must be a valid number.');
  return Number(digits);
}
function getQuotedDocument(message) {
  const context = message.message?.extendedTextMessage?.contextInfo;
  const quoted = context?.quotedMessage;
  if (!quoted?.documentMessage) return null;
  return { key: { remoteJid: message.key.remoteJid, id: context.stanzaId, participant: context.participant }, message: { documentMessage: quoted.documentMessage } };
}

// TXT format:
// # BRAND / PRODUCT NAME
// Variant Name|Price
// The # header is a product/brand inside one category. There is no stock system in the catalog.
function parseProductFile(content) {
  const lines = String(content).replace(/^\uFEFF/, '').split(/\r?\n/);
  const products = [];
  let currentProduct = '';
  const errors = [];
  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i].trim();
    if (!raw) continue;
    if (raw.startsWith('#')) {
      currentProduct = raw.slice(1).trim();
      if (!currentProduct) errors.push(i + 1);
      continue;
    }
    if (!currentProduct) { errors.push(i + 1); continue; }
    const parts = raw.split('|').map((part) => part.trim());
    if (parts.length < 2 || !parts[0] || !parts[1]) { errors.push(i + 1); continue; }
    try {
      products.push({ product: currentProduct, name: parts[0], price: parsePrice(parts[1]), description: '' });
    } catch { errors.push(i + 1); }
  }
  return { products, errors };
}

function getOrCreateProduct(ctx, cat, name) {
  const key = ensureStoreGroup(ctx.jid);
  const existing = db().prepare('SELECT * FROM store_products WHERE group_jid=? AND category_id=? AND lower(name)=lower(?) ORDER BY id LIMIT 1').get(key, cat.id, name);
  if (existing) return existing;
  const now = Date.now();
  const result = db().prepare('INSERT INTO store_products(group_jid,category_id,name,price,description,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').run(key, cat.id, name, 0, '', now, now);
  return db().prepare('SELECT * FROM store_products WHERE id=?').get(result.lastInsertRowid);
}

function upsertVariant(product, item) {
  const now = Date.now();
  let variant = db().prepare('SELECT * FROM store_variants WHERE product_id=? AND lower(name)=lower(?) ORDER BY id LIMIT 1').get(product.id, item.name);
  if (!variant) {
    const result = db().prepare('INSERT INTO store_variants(product_id,name,price,description,created_at,updated_at) VALUES(?,?,?,?,?,?)').run(product.id, item.name, item.price, item.description || '', now, now);
    return db().prepare('SELECT * FROM store_variants WHERE id=?').get(result.lastInsertRowid);
  }
  db().prepare('UPDATE store_variants SET price=?, description=?, updated_at=? WHERE id=?').run(item.price, item.description || '', now, variant.id);
  return db().prepare('SELECT * FROM store_variants WHERE id=?').get(variant.id);
}

function getProducts(ctx, cat) {
  const key = ensureStoreGroup(ctx.jid);
  return db().prepare('SELECT * FROM store_products WHERE group_jid=? AND category_id=? ORDER BY id ASC').all(key, cat.id);
}
function getVariants(productId) {
  return db().prepare('SELECT * FROM store_variants WHERE product_id=? ORDER BY id ASC').all(productId);
}

function normalizeGroupJid(value) {
  const raw = String(value || '').trim().replace(/^['"]|['"]$/g, '');
  if (!raw) return '';
  if (/^https?:\/\//i.test(raw)) {
    const match = raw.match(/([0-9]+(?:-[0-9]+)?@g\.us)/i);
    return match ? match[1] : '';
  }
  return raw.split(':')[0];
}

async function copyStoreGroup(sourceJid, targetJid, root) {
  const database = db();
  const source = storeGroupJid(sourceJid);
  const target = storeGroupJid(targetJid);
  if (!source || !target || !source.endsWith('@g.us') || !target.endsWith('@g.us')) {
    throw new Error('Both source and target must be valid WhatsApp group JIDs.');
  }
  if (source === target) throw new Error('Source and target groups must be different.');

  // Ensure the target group row exists before inserting categories/products.
  // The Store tables use a foreign key to groups(jid), so a fresh target group
  // would otherwise fail with SQLITE_CONSTRAINT_FOREIGNKEY.
  ensureStoreGroup(target);

  const sourceGroup = getGroup(source);
  const categories = database.prepare('SELECT * FROM store_categories WHERE group_jid=? ORDER BY id ASC').all(source);
  const products = database.prepare('SELECT * FROM store_products WHERE group_jid=? ORDER BY id ASC').all(source);
  const variantsByProduct = new Map();
  for (const product of products) variantsByProduct.set(product.id, getVariants(product.id));
  const stock = database.prepare(`
    SELECT s.* FROM store_stock s
    JOIN store_products p ON p.id=s.product_id
    WHERE p.group_jid=? ORDER BY s.id ASC
  `).all(source);

  const bannerMap = new Map();
  const copyBanner = async (relative, suffix) => {
    if (!relative) return '';
    const sourceFile = path.join(root, relative);
    try {
      await fs.access(sourceFile);
      const ext = path.extname(relative) || '.png';
      const parts = String(suffix).split('/').filter(Boolean).map(safeFile);
      const filename = `${parts.pop() || 'banner'}${ext}`;
      const targetRelative = path.join('data', 'store-banners', safeFile(target), ...parts, filename);
      const targetFile = path.join(root, targetRelative);
      await fs.mkdir(path.dirname(targetFile), { recursive: true });
      await fs.copyFile(sourceFile, targetFile);
      return targetRelative;
    } catch {
      return '';
    }
  };

  // Copy banner files first so the target never points at the source group's files.
  // Each target group gets its own folder: store-banners/<group-jid>/...
  const storeBanner = await copyBanner(sourceGroup.store?.banner || '', 'store');
  for (const cat of categories) {
    bannerMap.set(cat.id, await copyBanner(cat.banner || '', `categories/${safeFile(cat.slug)}`));
  }

  const tx = database.transaction(() => {
    const now = Date.now();
    const categoryMap = new Map();
    const productMap = new Map();
    const variantMap = new Map();

    // ADDITIVE COPY: never delete or replace anything already in the target group.
    for (const cat of categories) {
      let targetCat = database.prepare('SELECT * FROM store_categories WHERE group_jid=? AND slug=?').get(target, cat.slug);
      if (!targetCat) {
        const result = database.prepare(
          'INSERT INTO store_categories(group_jid,slug,name,banner,created_at) VALUES(?,?,?,?,?)'
        ).run(target, cat.slug, cat.name, bannerMap.get(cat.id) || '', cat.created_at || now);
        targetCat = database.prepare('SELECT * FROM store_categories WHERE id=?').get(result.lastInsertRowid);
      } else if (!targetCat.banner && bannerMap.get(cat.id)) {
        database.prepare('UPDATE store_categories SET banner=? WHERE id=?').run(bannerMap.get(cat.id), targetCat.id);
        targetCat = database.prepare('SELECT * FROM store_categories WHERE id=?').get(targetCat.id);
      }
      categoryMap.set(cat.id, targetCat.id);
    }

    for (const product of products) {
      const newCategoryId = categoryMap.get(product.category_id);
      if (!newCategoryId) continue;

      let targetProduct = database.prepare(
        'SELECT * FROM store_products WHERE group_jid=? AND category_id=? AND lower(name)=lower(?) ORDER BY id LIMIT 1'
      ).get(target, newCategoryId, product.name);

      if (!targetProduct) {
        const result = database.prepare(
          'INSERT INTO store_products(group_jid,category_id,name,price,description,created_at,updated_at) VALUES(?,?,?,?,?,?,?)'
        ).run(target, newCategoryId, product.name, product.price || 0, product.description || '', product.created_at || now, product.updated_at || now);
        targetProduct = database.prepare('SELECT * FROM store_products WHERE id=?').get(result.lastInsertRowid);
      }
      productMap.set(product.id, targetProduct.id);

      for (const variant of variantsByProduct.get(product.id) || []) {
        let targetVariant = database.prepare(
          'SELECT * FROM store_variants WHERE product_id=? AND lower(name)=lower(?) ORDER BY id LIMIT 1'
        ).get(targetProduct.id, variant.name);
        if (!targetVariant) {
          const vResult = database.prepare(
            'INSERT INTO store_variants(product_id,name,price,description,created_at,updated_at) VALUES(?,?,?,?,?,?)'
          ).run(targetProduct.id, variant.name, variant.price || 0, variant.description || '', variant.created_at || now, variant.updated_at || now);
          targetVariant = database.prepare('SELECT * FROM store_variants WHERE id=?').get(vResult.lastInsertRowid);
        }
        variantMap.set(variant.id, targetVariant.id);
      }
    }

    // Copy only stock items that do not already exist in the target.
    let copiedStock = 0;
    for (const item of stock) {
      const newProductId = productMap.get(item.product_id);
      if (!newProductId) continue;
      const newVariantId = item.variant_id ? (variantMap.get(item.variant_id) || null) : null;
      const exists = database.prepare(
        'SELECT id FROM store_stock WHERE product_id=? AND (variant_id IS ? OR variant_id=?) AND content=? LIMIT 1'
      ).get(newProductId, newVariantId, newVariantId, item.content);
      if (exists) continue;
      database.prepare(
        'INSERT INTO store_stock(product_id,variant_id,content,created_at,sold_at) VALUES(?,?,?,?,?)'
      ).run(newProductId, newVariantId, item.content, item.created_at || now, item.sold_at || null);
      copiedStock++;
    }

    const targetGroup = getGroup(target);
    // Only fill Store settings when the target has no custom value yet.
    targetGroup.store = {
      ...targetGroup.store,
      name: targetGroup.store?.name && targetGroup.store.name !== 'Store' ? targetGroup.store.name : (sourceGroup.store?.name || 'Store'),
      banner: targetGroup.store?.banner || storeBanner || ''
    };
    database.prepare('INSERT INTO groups(jid,data) VALUES(?,?) ON CONFLICT(jid) DO UPDATE SET data=excluded.data')
      .run(target, JSON.stringify(targetGroup));

    return {
      categories: categories.length,
      products: products.length,
      variants: [...variantsByProduct.values()].reduce((n, list) => n + list.length, 0),
      stock: copiedStock,
      name: targetGroup.store.name
    };
  });

  return tx();
}

function catalog(ctx, cat) {
  const products = getProducts(ctx, cat);
  const group = getGroup(storeGroupJid(ctx.jid));
  const lines = [`╭───『 ${group.store.name} 』`, `│ ${cat.name}`, '│'];
  if (!products.length) {
    lines.push('│ No products available.');
  } else {
    for (const [index, p] of products.entries()) {
      const variants = getVariants(p.id);
      lines.push(`│ ${index + 1}. ${p.name}`);
      if (!variants.length) {
        if (p.price) lines.push(`│    ${money(p.price)}`);
        if (p.description) lines.push(`│    ${p.description}`);
      } else {
        variants.forEach((v, vi) => {
          const branch = vi === variants.length - 1 ? '└─' : '├─';
          lines.push(`│    ${branch} ${v.name} — ${money(v.price)}`);
          if (v.description) lines.push(`│       ${v.description}`);
        });
      }
      if (index !== products.length - 1) lines.push('│');
    }
  }
  lines.push('│', '│ Use .p <keyword> to search.', '╰────────────');
  return lines.join('\n');
}

function productDetail(ctx, cat, product, selectedVariant = null) {
  const variants = getVariants(product.id);
  const lines = [`╭───『 ${product.name} 』`, `│ Category: ${cat.name}`, '│'];
  if (selectedVariant) {
    lines.push(`│ ${selectedVariant.name}`, `│ Price: ${money(selectedVariant.price)}`);
    if (selectedVariant.description) lines.push(`│ ${selectedVariant.description}`);
  } else if (variants.length) {
    variants.forEach((v, i) => {
      const branch = i === variants.length - 1 ? '└─' : '├─';
      lines.push(`│ ${branch} ${v.name} — ${money(v.price)}`);
      if (v.description) lines.push(`│    ${v.description}`);
    });
  } else {
    if (product.price) lines.push(`│ Price: ${money(product.price)}`);
    if (product.description) lines.push(`│ ${product.description}`);
  }
  lines.push('╰────────────');
  return lines.join('\n');
}

function searchProducts(ctx, keyword) {
  const key = ensureStoreGroup(ctx.jid);
  const term = String(keyword || '').trim().toLowerCase();
  if (!term) return [];
  const rows = db().prepare(`
    SELECT p.*, c.name AS category_name, c.slug AS category_slug
    FROM store_products p
    JOIN store_categories c ON c.id=p.category_id
    WHERE p.group_jid=? AND (lower(p.name) LIKE ? OR EXISTS (
      SELECT 1 FROM store_variants v WHERE v.product_id=p.id AND lower(v.name) LIKE ?
    ))
    ORDER BY p.id ASC
  `).all(key, `${term}%`, `${term}%`);
  return rows;
}

function searchCatalog(ctx, keyword) {
  const results = searchProducts(ctx, keyword);
  const lines = [`╭───『 ${getGroup(storeGroupJid(ctx.jid)).store.name} 』`, `│ Search: ${keyword}`, '│'];
  if (!results.length) {
    lines.push('│ No matching products found.');
  } else {
    results.forEach((p, i) => {
      lines.push(`│ ${p.name}`);
      const variants = getVariants(p.id);
      if (variants.length) {
        variants.forEach((v, vi) => {
          const branch = vi === variants.length - 1 ? '└─' : '├─';
          lines.push(`│    ${branch} ${v.name} — ${money(v.price)}`);
        });
      } else if (p.price) {
        lines.push(`│    └─ ${money(p.price)}`);
      }
      if (i !== results.length - 1) lines.push('│');
    });
  }
  lines.push('╰────────────');
  return lines.join('\n');
}

async function sendStoreImage(ctx, text, banner) {
  if (!banner) return ctx.sock.sendMessage(ctx.jid, { text });
  try {
    const buffer = await fs.readFile(path.join(ctx.config.root, banner));
    return ctx.sock.sendMessage(ctx.jid, { image: buffer, caption: text });
  } catch {
    return ctx.sock.sendMessage(ctx.jid, { text });
  }
}

export const command = {
  names: ['store', 'addcategory', 'delcategory', 'listcategory', 'setcategorybanner', 'setstorename', 'setstorebanner', 'addproduct', 'delproduct', 'editproduct', 'storecopy', 'storeaccess'],
  aliases: ['category', 'p', 'storegrant', 'storeallow', 'storedeny'],
  async execute(ctx) {
    const c = ctx.commandName;

    // Store access management is owner-only and can be used from private chat or groups.
    if (['storeaccess', 'storegrant', 'storeallow', 'storedeny'].includes(c)) {
      if (!ctx.isOwner) return ctx.sock.sendMessage(ctx.jid, { text: 'Owner only.' });
      const action = c === 'storegrant' || c === 'storeallow' ? 'add' : c === 'storedeny' ? 'remove' : String(ctx.args?.[0] || '').toLowerCase();

      if (action === 'list') {
        const rows = listStoreAccess();
        if (!rows.length) return ctx.sock.sendMessage(ctx.jid, { text: 'Store access list is empty.' });
        const lines = ['Store Access', ''];
        rows.forEach((row, i) => lines.push(`${i + 1}. @${displayJid(row.jid)}`));
        return ctx.sock.sendMessage(ctx.jid, { text: lines.join('\n'), mentions: rows.map((row) => row.jid) });
      }

      if (!['add', 'remove'].includes(action)) {
        return ctx.sock.sendMessage(ctx.jid, { text: `Usage:\n.storeaccess add @user\n.storeaccess remove @user\n.storeaccess list` });
      }

      const target = targetUserJid(ctx);
      if (!target) return ctx.sock.sendMessage(ctx.jid, { text: `Usage: .storeaccess ${action} @user` });
      if (ctx.isOwner && target === String(ctx.senderDisplayJid || ctx.sender || '').split(':')[0]) {
        return ctx.sock.sendMessage(ctx.jid, { text: 'The owner already has Store access.' });
      }

      if (action === 'add') {
        addStoreAccess(target);
        await saveDatabase();
        return ctx.sock.sendMessage(ctx.jid, { text: `Store access granted to @${displayJid(target)}.`, mentions: [target] });
      }

      const removed = removeStoreAccess(target);
      await saveDatabase();
      return ctx.sock.sendMessage(ctx.jid, { text: removed ? `Store access removed from @${displayJid(target)}.` : 'That user does not have Store access.', mentions: [target] });
    }

    requireGroup(ctx);
    const group = getGroup(storeGroupJid(ctx.jid));

    // Public Store catalog: every group member can browse the Store.
    // Store management commands below remain protected by Store access/admin checks.
    if (c === 'store') {
      const requested = ctx.args.join(' ').trim();
      const key = ensureStoreGroup(ctx.jid);
      if (!requested) {
        const cats = db().prepare('SELECT name, slug FROM store_categories WHERE group_jid=? ORDER BY id').all(key);
        const text = [`╭───『 ${group.store.name} 』`, '│ Store Categories', '│'];
        if (!cats.length) text.push('│ No categories yet.');
        else cats.forEach((cat, i) => text.push(`│ ${i + 1}. ${cat.name}`));
        text.push('╰────────────', '', `Use ${ctx.config.prefix}store <number> or <category>.`);
        return sendStoreImage(ctx, text.join('\n'), group.store.banner);
      }

      // Support numeric category shortcuts: .store 1, .store 2, etc.
      let cat = null;
      if (/^\d+$/.test(requested)) {
        const index = Number(requested);
        if (index < 1) throw new Error(`Category not found: ${requested}`);
        cat = db().prepare('SELECT * FROM store_categories WHERE group_jid=? ORDER BY id LIMIT 1 OFFSET ?').get(key, index - 1) || null;
      } else {
        cat = category(ctx, requested);
      }
      if (!cat) throw new Error(`Category not found: ${requested}`);
      return sendStoreImage(ctx, catalog(ctx, cat), cat.banner || group.store.banner);
    }

    // Public Store search: every group member can search products.
    if (c === 'p') {
      const keyword = ctx.args.join(' ').trim();
      if (!keyword) throw new Error(`Usage: ${ctx.config.prefix}p <product name>`);
      return ctx.sock.sendMessage(ctx.jid, { text: searchCatalog(ctx, keyword) });
    }

    if (['storecopy','addcategory','delcategory','setcategorybanner','setstorename','setstorebanner','addproduct','delproduct','editproduct'].includes(c)) {
      requireStoreAccess(ctx);
    }

    if (c === 'storecopy') {
      requireAdmin(ctx);
      const source = normalizeGroupJid(ctx.args[0]);
      if (!source) throw new Error(`Usage: ${ctx.config.prefix}storecopy <source-group-jid>`);
      if (!source.endsWith('@g.us')) throw new Error('Invalid source group JID. Example: 120363012345678901@g.us');
      if (source === storeGroupJid(ctx.jid)) throw new Error('Source and target groups must be different.');

      const result = await copyStoreGroup(source, ctx.jid, ctx.config.root);
      await saveDatabase();
      return ctx.sock.sendMessage(ctx.jid, {
        text: `📦 Store copy completed.\n\nSource: ${source}
Target: ${storeGroupJid(ctx.jid)}\nMode: Additive copy (existing target Store data is preserved).\nCategories copied: ${result.categories}\nProducts copied: ${result.products}\nTypes copied: ${result.variants}\nStock copied: ${result.stock}\nStore name: ${result.name}`
      });
    }

    if (c === 'addcategory') {
      requireAdmin(ctx);
      const name = ctx.args.join(' ').trim();
      if (!name) throw new Error(`Usage: ${ctx.config.prefix}addcategory <name>`);
      const slug = slugify(name);
      if (!slug) throw new Error('Invalid category name.');
      const key = ensureStoreGroup(ctx.jid);
      try {
        db().prepare('INSERT INTO store_categories(group_jid,slug,name,banner,created_at) VALUES(?,?,?,?,?)').run(key, slug, name, '', Date.now());
      } catch (error) {
        if (String(error?.message || '').includes('UNIQUE')) throw new Error('That category already exists.');
        console.error('[store] addcategory failed:', error?.message || error);
        throw new Error('Failed to create category.');
      }
      await saveDatabase();
      return ctx.sock.sendMessage(ctx.jid, { text: `✅ Category created: ${name}\nSlug: ${slug}` });
    }

    if (c === 'delcategory') {
      requireAdmin(ctx);
      const cat = category(ctx, ctx.args.join(' '));
      if (!cat) throw new Error('Category not found.');
      db().prepare('DELETE FROM store_categories WHERE id=?').run(cat.id);
      if (cat.banner) { try { await fs.unlink(path.join(ctx.config.root, cat.banner)); } catch {} }
      return ctx.sock.sendMessage(ctx.jid, { text: `✅ Category deleted: ${cat.name}` });
    }

    if (c === 'listcategory') {
      const key = ensureStoreGroup(ctx.jid);
      const cats = db().prepare(`SELECT c.*, COUNT(DISTINCT p.id) AS products FROM store_categories c LEFT JOIN store_products p ON p.category_id=c.id WHERE c.group_jid=? GROUP BY c.id ORDER BY c.id`).all(key);
      const lines = [`╭───『 ${group.store.name} CATEGORIES 』`];
      if (!cats.length) lines.push('│ No categories yet.');
      else cats.forEach((cat, i) => lines.push(`│ ${i + 1}. ${cat.name} (${cat.slug})\n│    Products: ${cat.products}`));
      lines.push('╰────────────');
      return ctx.sock.sendMessage(ctx.jid, { text: lines.join('\n') });
    }

    if (c === 'setcategorybanner') {
      requireAdmin(ctx);
      const reset = ['reset','remove','off'].includes(String(ctx.args.at(-1) || '').toLowerCase());
      const catArg = (reset ? ctx.args.slice(0, -1) : ctx.args).join(' ');
      const cat = category(ctx, catArg);
      if (!cat) throw new Error('Category not found.');
      if (reset) {
        if (cat.banner) { try { await fs.unlink(path.join(ctx.config.root, cat.banner)); } catch {} }
        db().prepare('UPDATE store_categories SET banner=? WHERE id=?').run('', cat.id);
        return ctx.sock.sendMessage(ctx.jid, { text: `✅ Category banner removed: ${cat.name}` });
      }
      const current = ctx.message.message?.imageMessage;
      const context = ctx.message.message?.extendedTextMessage?.contextInfo;
      const quotedImage = context?.quotedMessage?.imageMessage ? { key: { remoteJid: ctx.jid, id: context.stanzaId, participant: context.participant }, message: { imageMessage: context.quotedMessage.imageMessage } } : null;
      const target = current ? ctx.message : quotedImage;
      if (!target) throw new Error(`Send/reply to an image with ${ctx.config.prefix}setcategorybanner <category>.`);
      const buffer = await downloadMedia(target, 'imageMessage');
      const folder = path.join(ctx.config.dataDir, 'store-banners', safeFile(ctx.jid), 'categories');
      await fs.mkdir(folder, { recursive: true });
      const relative = path.join('data', 'store-banners', safeFile(ctx.jid), 'categories', `${safeFile(cat.slug)}.png`);
      await sharp(buffer).rotate().resize(1200, 630, { fit: 'cover', position: 'centre' }).png().toFile(path.join(ctx.config.root, relative));
      if (cat.banner && cat.banner !== relative) { try { await fs.unlink(path.join(ctx.config.root, cat.banner)); } catch {} }
      db().prepare('UPDATE store_categories SET banner=? WHERE id=?').run(relative, cat.id);
      return ctx.sock.sendMessage(ctx.jid, { text: `✅ Category banner saved: ${cat.name}` });
    }

    if (c === 'setstorename') {
      requireAdmin(ctx);
      const value = ctx.args.join(' ').trim();
      if (!value) throw new Error(`Usage: ${ctx.config.prefix}setstorename <name>\nReset: ${ctx.config.prefix}setstorename reset`);
      group.store.name = value.toLowerCase() === 'reset' ? 'Store' : value;
      await saveDatabase();
      return ctx.sock.sendMessage(ctx.jid, { text: `✅ Store name set to: ${group.store.name}` });
    }

    if (c === 'setstorebanner') {
      requireAdmin(ctx);
      const value = String(ctx.args.join(' ') || '').trim().toLowerCase();
      if (['reset', 'remove', 'off'].includes(value)) {
        if (group.store.banner) { try { await fs.unlink(path.join(ctx.config.root, group.store.banner)); } catch {} }
        group.store.banner = '';
        await saveDatabase();
        return ctx.sock.sendMessage(ctx.jid, { text: '✅ Store banner removed.' });
      }
      const current = ctx.message.message?.imageMessage;
      const context = ctx.message.message?.extendedTextMessage?.contextInfo;
      const quotedImage = context?.quotedMessage?.imageMessage ? { key: { remoteJid: ctx.jid, id: context.stanzaId, participant: context.participant }, message: { imageMessage: context.quotedMessage.imageMessage } } : null;
      const target = current ? ctx.message : quotedImage;
      if (!target) throw new Error(`Send/reply to an image with ${ctx.config.prefix}setstorebanner.`);
      const buffer = await downloadMedia(target, 'imageMessage');
      const folder = path.join(ctx.config.dataDir, 'store-banners', safeFile(ctx.jid));
      await fs.mkdir(folder, { recursive: true });
      const relative = path.join('data', 'store-banners', safeFile(ctx.jid), 'store.png');
      await sharp(buffer).rotate().resize(1200, 630, { fit: 'cover', position: 'centre' }).png().toFile(path.join(ctx.config.root, relative));
      if (group.store.banner && group.store.banner !== relative) { try { await fs.unlink(path.join(ctx.config.root, group.store.banner)); } catch {} }
      group.store.banner = relative;
      await saveDatabase();
      return ctx.sock.sendMessage(ctx.jid, { text: '✅ Store banner saved successfully.' });
    }

    if (c === 'addproduct') {
      requireAdmin(ctx);
      const cat = category(ctx, ctx.args.join(' '));
      const quotedDoc = getQuotedDocument(ctx.message);
      const currentDoc = ctx.message.message?.documentMessage;
      if (quotedDoc || currentDoc) {
        if (!cat) throw new Error(`Category not found. Usage: ${ctx.config.prefix}addproduct <category>`);
        const target = currentDoc ? ctx.message : quotedDoc;
        const filename = target.message.documentMessage.fileName || '';
        if (!filename.toLowerCase().endsWith('.txt')) throw new Error('Only .txt files are supported.');
        const buffer = await downloadMedia(target, 'documentMessage');
        const parsed = parseProductFile(buffer.toString('utf8'));
        if (!parsed.products.length) throw new Error('No valid product lines found in the TXT file.');
        const tx = db().transaction((items) => {
          for (const item of items) {
            const product = getOrCreateProduct(ctx, cat, item.product);
            upsertVariant(product, item);
          }
        });
        tx(parsed.products);
        const brands = new Set(parsed.products.map((x) => x.product));
        return ctx.sock.sendMessage(ctx.jid, { text: `✅ TXT import completed.\nCategory: ${cat.name}\nProducts: ${brands.size}\nTypes: ${parsed.products.length}\nInvalid lines: ${parsed.errors.length}${parsed.errors.length ? `\nLines: ${parsed.errors.join(', ')}` : ''}` });
      }
      const raw = ctx.args.join(' ');
      const parts = raw.split('|').map((x) => x.trim());
      if (parts.length < 4) throw new Error(`Usage: ${ctx.config.prefix}addproduct <category> | <product> | <type> | <price>`);
      const selected = category(ctx, parts.shift());
      if (!selected) throw new Error('Category not found.');
      const item = { product: parts.shift(), name: parts.shift(), price: parsePrice(parts.shift()), description: '' };
      const product = getOrCreateProduct(ctx, selected, item.product);
      upsertVariant(product, item);
      return ctx.sock.sendMessage(ctx.jid, { text: `✅ Product type saved.\n${item.product}\n${item.name}\n${money(item.price)}` });
    }


    if (c === 'delproduct') {
      requireAdmin(ctx);
      const [catArg, indexArg] = ctx.args;
      const cat = category(ctx, catArg);
      if (!cat) throw new Error('Category not found.');
      const index = Number(indexArg);
      const products = getProducts(ctx, cat);
      const p = products[index - 1];
      if (!p) throw new Error('Product not found.');
      db().prepare('DELETE FROM store_products WHERE id=?').run(p.id);
      return ctx.sock.sendMessage(ctx.jid, { text: `✅ Product deleted: ${p.name}` });
    }

    if (c === 'editproduct') {
      requireAdmin(ctx);
      const parts = ctx.args.join(' ').split('|').map((x) => x.trim());
      if (parts.length < 6) throw new Error(`Usage: ${ctx.config.prefix}editproduct <category> | <product-number> | <type-number> | <type-name> | <price> | <description>`);
      const cat = category(ctx, parts[0]);
      if (!cat) throw new Error('Category not found.');
      const pIndex = Number(parts[1]);
      const vIndex = Number(parts[2]);
      const products = getProducts(ctx, cat);
      const p = products[pIndex - 1];
      if (!p) throw new Error('Product not found.');
      const variants = getVariants(p.id);
      const v = variants[vIndex - 1];
      if (!v) throw new Error('Product type not found.');
      db().prepare('UPDATE store_variants SET name=?, price=?, description=?, updated_at=? WHERE id=?').run(parts[3], parsePrice(parts[4]), parts.slice(5).join(' | '), Date.now(), v.id);
      return ctx.sock.sendMessage(ctx.jid, { text: `✅ Product type updated: ${p.name} / ${parts[3]}` });
    }
  }
};
