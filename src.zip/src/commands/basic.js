import os from 'node:os';
import { formatUptime, jidNumber } from '../lib/utils.js';
const ok = async ({ sock, jid }, text) => sock.sendMessage(jid, { text });
export const command = { names: ['ping','runtime','botinfo','owner','jid','timestamp'], async execute(ctx) {
  const n = ctx.args[0];
  if (ctx.text.toLowerCase().startsWith(ctx.config.prefix + 'ping')) return ok(ctx, `🏓 Pong!\nUptime: ${formatUptime(process.uptime())}`);
  if (ctx.text.toLowerCase().startsWith(ctx.config.prefix + 'runtime')) return ok(ctx, `⏱ Runtime: ${formatUptime(process.uptime())}`);
  if (ctx.text.toLowerCase().startsWith(ctx.config.prefix + 'botinfo')) return ok(ctx, `🤖 ${ctx.config.botName}\nNode: ${process.version}\nPlatform: ${process.platform}\nMemory: ${Math.round(process.memoryUsage().rss/1024/1024)} MB\nCPU: ${os.cpus()[0]?.model ?? 'Unknown'}`);
  if (ctx.text.toLowerCase().startsWith(ctx.config.prefix + 'owner')) {
    const owners = (ctx.config.ownerNumbers || []).map((value) => String(value).replace(/\D/g, '')).filter(Boolean);
    const mentions = owners.map((number) => `${number}@s.whatsapp.net`);
    const lines = owners.length
      ? owners.map((number, i) => `${i + 1}. 👑 @${number}`).join('\n')
      : 'No owner number is configured.';
    return ctx.sock.sendMessage(ctx.jid, {
      text: [
        '╭━━〔 👑 BOT OWNER 〕━━╮',
        `│ Total Owners : ${owners.length}`,
        '╰━━━━━━━━━━━━━━━━━━━━╯',
        '',
        '👑 *OWNER CONTACTS*',
        lines,
        '',
        '▧──···「 *ᴏғғɪᴄɪᴀʟ ᴏᴡɴᴇʀ* 」',
        '│ Contact the owner above for bot management, support, or inquiries.',
        '╰────────────────────'
      ].join('\n'),
      mentions
    });
  }
  if (ctx.text.toLowerCase().startsWith(ctx.config.prefix + 'jid')) return ok(ctx, `Chat JID: ${ctx.jid}\nSender: ${ctx.sender}`);
  if (ctx.text.toLowerCase().startsWith(ctx.config.prefix + 'timestamp')) return ok(ctx, `${Date.now()}\n${new Date().toISOString()}`);
} };
